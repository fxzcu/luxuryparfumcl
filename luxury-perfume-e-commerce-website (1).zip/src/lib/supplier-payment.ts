import type { orders } from "@/db/schema";

export function supplierPaymentConfigurationError(provider: string): string | null {
  if (provider !== "transbank") return "Webpay Plus es el único medio de pago disponible.";
  return process.env.TRANSBANK_COMMERCE_CODE && process.env.TRANSBANK_API_KEY
    ? null
    : "Webpay aún no está activado. No se creó un pedido de pago ni se realizó un cobro.";
}

export async function initiateSupplierPayment(order: typeof orders.$inferSelect, baseUrl: string) {
  const configurationError = supplierPaymentConfigurationError(order.paymentProvider);
  if (configurationError) throw new Error(configurationError);
  const host = process.env.TRANSBANK_ENV === "production" ? "https://webpay3g.transbank.cl" : "https://webpay3gint.transbank.cl";
  const response = await fetch(`${host}/rswebpaytransaction/api/webpay/v1.2/transactions`, {
    method: "POST",
    headers: { "Tbk-Api-Key-Id": process.env.TRANSBANK_COMMERCE_CODE!, "Tbk-Api-Key-Secret": process.env.TRANSBANK_API_KEY!, "Content-Type": "application/json" },
    body: JSON.stringify({ buy_order: order.orderNumber, session_id: `LPC-${order.id}`, amount: order.total, return_url: `${baseUrl}/api/payments/transbank/return?contact=1` }),
    signal: AbortSignal.timeout(15_000),
  });
  const result = await response.json() as { token?: string; url?: string };
  if (!response.ok || !result.token || !result.url) throw new Error("Webpay no pudo iniciar el pago.");
  return { provider: "transbank" as const, url: result.url, token: result.token, reference: result.token };
}
