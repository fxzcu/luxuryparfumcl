import { NextRequest, NextResponse } from "next/server";
import { ADMIN_COOKIE, isValidAdminToken } from "@/lib/admin-auth";

export function requireAdmin(request: NextRequest) {
  if (isValidAdminToken(request.cookies.get(ADMIN_COOKIE)?.value)) return null;
  return NextResponse.json({ error: "Inicia sesión para acceder al panel." }, { status: 401 });
}
