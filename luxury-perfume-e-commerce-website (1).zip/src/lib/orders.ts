import { and, eq, gte, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { customers, orders, products, suppliers } from "@/db/schema";

function escapeHtml(value: string) {
  const entities: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  return value.replace(/[&<>"']/g, (character) => entities[character] ?? character);
}

function clp(amount: number) {
  return new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(amount);
}

export async function sendConfirmationEmail(orderNumber: string) {
  const [record] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  if (!record || record.paymentStatus !== "paid") return { sent: false, error: "El pago todavía no está confirmado." };
  if (record.confirmationEmailSentAt) return { sent: true };
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL;
  if (!apiKey || !from) return { sent: false, error: "Configura RESEND_API_KEY y RESEND_FROM_EMAIL para enviar correos." };
  const [customer] = await db.select().from(customers).where(eq(customers.id, record.customerId)).limit(1);
  if (!customer?.email) return { sent: false, error: "El pedido no tiene un correo válido." };

  let deliveryHtml = record.fulfillment === "pickup"
    ? "Te contactaremos para coordinar el retiro de tu pedido."
    : "El envío de tus perfumes demora entre <strong>14 y 18 días</strong> desde la confirmación del pago.";
  const digital = record.fulfillment === "digital";
  if (digital && record.contactDelivery === "email") {
    const ids = [...new Set(record.items.flatMap((item) => item.contactSupplierIds ?? (item.supplierId ? [item.supplierId] : [])))];
    if (!ids.length) return { sent: false, error: "El pedido no contiene un contacto de proveedor." };
    const contacts = await db.select({ id: suppliers.id, name: suppliers.name, contact: suppliers.contact }).from(suppliers).where(inArray(suppliers.id, ids));
    if (contacts.length !== new Set(ids).size || contacts.some((supplier) => !supplier.contact.trim())) {
      return { sent: false, error: "Completa el contacto privado del proveedor antes de enviar la entrega." };
    }
    deliveryHtml = `<h2>Tus contactos de proveedores</h2>${contacts.map((supplier) => `<div style="padding:18px;background:#f4f1e9;margin:12px 0"><strong>${escapeHtml(supplier.name)}</strong><p style="white-space:pre-wrap">${escapeHtml(supplier.contact)}</p></div>`).join("")}<p>Compra digital. No incluye productos físicos ni gastos de despacho.</p>`;
  } else if (digital) {
    deliveryHtml = `Enviaremos los contactos adquiridos por mensaje de TikTok a <strong>${escapeHtml(record.tiktokHandle)}</strong>. Incluye: ${escapeHtml(record.items.flatMap((item) => item.includedContactNames ?? [item.name]).join(", "))}. Mantén habilitados tus mensajes directos; si no podemos contactarte por allí, coordinaremos contigo por este correo. La entrega por TikTok es manual, no automática.`;
  }

  const rows = record.items.map((item) => `<tr><td style="padding:10px 0;border-bottom:1px solid #eee">${escapeHtml(item.brand)} · ${escapeHtml(item.name)} (${escapeHtml(item.size)}) × ${item.quantity}</td><td style="padding:10px 0;border-bottom:1px solid #eee;text-align:right">${clp(item.unitPrice * item.quantity)}</td></tr>`).join("");
  const html = `<div style="font-family:Arial,sans-serif;color:#24221e;max-width:620px;margin:auto"><p style="letter-spacing:3px;color:#997b45">LUXURY PARFUM CL</p><h1>Tu pedido está confirmado</h1><p>Hola ${escapeHtml(customer.fullName)}, recibimos tu pago para el pedido <strong>${escapeHtml(record.orderNumber)}</strong>.</p><table style="width:100%;border-collapse:collapse">${rows}<tr><td style="padding:14px 0">${digital ? "Entrega digital" : "Despacho"}</td><td style="text-align:right">${record.shipping ? clp(record.shipping) : "Sin costo"}</td></tr><tr><td style="padding:12px 0;font-weight:bold">Total</td><td style="text-align:right;font-weight:bold">${clp(record.total)}</td></tr></table><div>${deliveryHtml}</div><p>Gracias por elegir Luxury Parfum CL.</p></div>`;
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json", "Idempotency-Key": `order-confirmation-${record.orderNumber}` },
      body: JSON.stringify({ from, to: [customer.email], subject: `${digital && record.contactDelivery === "email" ? "Tus contactos de proveedores" : "Pedido confirmado"} · ${record.orderNumber}`, html }),
      signal: AbortSignal.timeout(15_000),
    });
    if (!response.ok) return { sent: false, error: "El proveedor de correo no aceptó el envío. Revisa su configuración e inténtalo nuevamente." };
    await db.update(orders).set({
      confirmationEmailSentAt: new Date(), updatedAt: new Date(),
      ...(digital && record.contactDelivery === "email" ? { status: "delivered", shipmentStatus: "delivered" } : {}),
    }).where(eq(orders.id, record.id));
    return { sent: true };
  } catch (error) {
    console.error("Unable to send order confirmation email", error);
    return { sent: false, error: "No pudimos enviar el correo. El pago sigue confirmado y la entrega permanece pendiente." };
  }
}

export async function confirmOrderByNumber(orderNumber: string, paymentReference: string) {
  let newlyConfirmed = false;
  let alreadyPaid = false;
  let stockConflict = false;
  try {
    await db.transaction(async (tx) => {
      const [order] = await tx.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1).for("update");
      if (!order || ["cancelled", "refunded", "awaiting_quote"].includes(order.status)) return;
      if (order.paymentStatus === "paid") { alreadyPaid = true; return; }
      for (const item of order.items) {
        if (item.kind === "supplier_contact" && item.supplierId) continue;
        if (!item.productId) throw new Error("El pedido contiene una referencia inválida.");
        const updated = await tx.update(products).set({ stock: sql`${products.stock} - ${item.quantity}`, updatedAt: new Date() })
          .where(and(eq(products.id, item.productId), gte(products.stock, item.quantity))).returning({ id: products.id });
        if (!updated.length) { stockConflict = true; throw new Error("Stock no disponible al confirmar el pago."); }
      }
      await tx.update(orders).set({ paymentStatus: "paid", paymentReference, status: "paid", ...(order.fulfillment === "digital" ? { shipmentStatus: "preparing" } : {}), updatedAt: new Date() }).where(eq(orders.id, order.id));
      newlyConfirmed = true;
    });
  } catch (error) {
    if (!stockConflict) console.error("Unable to confirm order", error);
    if (stockConflict) await db.update(orders).set({ paymentStatus: "paid_review", status: "stock_review", paymentReference, updatedAt: new Date() }).where(and(eq(orders.orderNumber, orderNumber), inArray(orders.paymentStatus, ["pending", "paid_review"])));
    return { confirmed: false, newlyConfirmed: false, stockConflict };
  }
  if (!newlyConfirmed && !alreadyPaid) return { confirmed: false, newlyConfirmed: false, stockConflict: false };
  await sendConfirmationEmail(orderNumber);
  return { confirmed: true, newlyConfirmed, stockConflict: false };
}
