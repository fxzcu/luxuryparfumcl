import originalPhotos from "@/lib/perfume-photos.json";
import { roundPerfumePrice } from "@/lib/perfume-pricing";

export type CatalogSeedRow = {
  brand: string;
  name: string;
  size: string;
  retailPrice: number;
  price: number;
  availability: string;
  gender: "Mujer" | "Hombre" | "Unisex";
  family: string;
  image: string;
  description: string;
  notes: string[];
  featured: boolean;
  slug: string;
};

// Valores de venta comunicados por Luxury Parfum CL: el segundo precio es el precio publicado.
const RAW_CATALOG = String.raw`Burberry|Brit Sheer EDT|100 ml|71990|46794
Burberry|London for Men EDT|100 ml|52370|34041
Burberry|London for Women EDP|100 ml|48620|31603
Burberry|Goddess EDP|100 ml|179990|116994
Burberry|Her Elixir EDP|100 ml|148990|96844
Burberry|My Burberry Black EDP|90 ml|179990|116994
Burberry|My Burberry Blush EDP|90 ml|169990|110494
Carolina Herrera|Good Girl EDP|80 ml|149990|97494
Carolina Herrera|Good Girl Blush EDP|80 ml|159990|103994
Carolina Herrera|Very Good Girl Elixir EDP|80 ml|166990|108544
Creed|Millésime Imperial EDP|100 ml|439890|285929
Creed|Silver Mountain Water EDP|100 ml|427990|278194
Dior|Sauvage EDP|100 ml|188100|122265
Dior|Homme Intense EDP|100 ml|188100|122265
Dior|Miss Dior EDP|100 ml|167400|108810
Jean Paul Gaultier|Divine EDP|100 ml|147990|96194
Jean Paul Gaultier|La Belle EDP|100 ml|142990|92944
Jean Paul Gaultier|Le Male Elixir Parfum|125 ml|155990|101394
Jean Paul Gaultier|Scandal Pour Homme EDT|100 ml|141990|92294
Tom Ford|Noir de Noir EDP|100 ml|328115|213275
Tom Ford|Ombre Leather Parfum|100 ml|298790|194214
Tom Ford|Soleil Neige EDP|100 ml|467990|304194
Valentino|Donna Born in Roma EDP|100 ml|163990|106594
Valentino|Uomo Born in Roma Intense EDP|100 ml|168990|109844
Versace|Bright Crystal Absolu EDP|90 ml|141990|92294
Versace|Bright Crystal Parfum|90 ml|161990|105294
Versace|Dylan Blue Pour Femme EDP|100 ml|86990|56544
Versace|Dylan Purple EDP|100 ml|141990|92294
Versace|Dylan Turquoise EDT|100 ml|115990|75394
Versace|Eros Energy EDP|100 ml|122990|79944
Versace|Eros Najim Parfum|100 ml|151990|98794
Versace|Eros Parfum|100 ml|151990|98794
Versace|Eros Pour Femme EDT|100 ml|115990|75394
Versace|Pour Homme EDT|50 ml|85990|55894
Versace|Versense EDT|100 ml|115990|75394
Versace|Yellow Diamond EDT|90 ml|117990|76694
Xerjoff|Alexandria II Anniversary EDP|100 ml|633990|412094
Xerjoff|Erba Gold EDP|100 ml|345990|224894
Xerjoff|Erba Pura EDP|100 ml|177990|115694
Xerjoff|Naxos EDP|100 ml|196990|128044
Xerjoff|Renaissance XJ 1861 EDP|100 ml|257990|167694
Xerjoff|Torino21 EDP|50 ml|142990|92944
Azzaro|The Most Wanted Rich|100 ml|119990|77994|E
Azzaro|The Most Wanted – Edición 2026|100 ml|119990|77994|E
Azzaro|The Most Wanted – Edición Lujosa|100 ml|119990|77994|E
Azzaro|Wanted Girl / Se Busca Mujer|80 ml|109990|71494|E
Azzaro|Wanted Gold Edition Rich Flavor (2026)|S/D|109990|71494|E
Burberry|Amber Heath (2017)|100 ml|155990|101394|E
Burberry|Clary Sage|100 ml|155990|101394|E
Burberry|Flower & Her Fruit Green Grape Gummy EDT|100 ml|149990|97494|E
Burberry|Goddess EDP / Goddess Rich|100 ml|179990|116994|E
Burberry|Goddess Rich Edition (2024)|S/D|179990|116994|E
Burberry|Goddess Rich Edition (2024)|S/D|179990|116994|E
Burberry|Haute Couture Amber Heath III|S/D|155990|101394|E
Burberry|Haute Couture Hawthorn Blossom|100 ml|155990|101394|E
Burberry|Her Blossom EDT|100 ml|126990|82544|V
Burberry|Her Intense (2025)|100 ml|150990|98144|V
Burberry|Her London Dream|100 ml|149990|97494|E
Burberry|Her Petals (2023)|100 ml|149990|97494|E
Burberry|Hero Intense|100 ml|169990|110494|E
Burberry|Midnight Journey (2021)|100 ml|155990|101394|E
Burberry|My Burberry EDP|90 ml|139990|90994|E
Burberry|My Burberry Pink – Nueva versión|90 ml|139990|90994|E
Burberry|Scarlet EDP|90 ml|155990|101394|E
Burberry|Yellow Exclusive EDP|90 ml|155990|101394|E
Carolina Herrera|Good Girl Blush Flower Language (2025)|80 ml|159990|103994|E
Carolina Herrera|Good Girl ColorMania|80 ml|149990|97494|E
Carolina Herrera|Good Girl ColorMania|80 ml|149990|97494|E
Carolina Herrera|Good Girl Fearless Glamorous Queen|85 ml|159990|103994|E
Carolina Herrera|Good Girl Légère|80 ml|149990|97494|E
Carolina Herrera|Good Girl New Edition Rosa Limitada|80 ml|149990|97494|E
Carolina Herrera|Good Girl Red High Heels|80 ml|149990|97494|E
Carolina Herrera|Good Girl Sparkling Ice (2024)|80 ml|159990|103994|E
Carolina Herrera|Good Girl Sparkling Ice (2024)|80 ml|159990|103994|E
Carolina Herrera|Good Girl Supreme|80 ml|149990|97494|E
Carolina Herrera|Good Girl Untamed Queen Purple Gold|80 ml|149990|97494|E
Carolina Herrera|Good Girl Untamed Queen Purple Gold|85 ml|159990|103994|E
Creed|Absolu Aventus (Éxito)|100 ml|459990|298994|E
Creed|Agua de Napoleón|100 ml|429990|279494|E
Creed|Aventus for Her (Mujer Exitosa)|100 ml|459990|298994|E
Creed|Centauro / Delphinus (2024)|S/D|429990|279494|E
Creed|Faith White Love / Black Love|75 ml|359990|233994|E
Creed|Fe en la Primavera|S/D|429990|279494|E
Creed|Himalaya / Snow Mountain Peak|100 ml|429990|279494|E
Creed|Incienso Ámbar Blanco / Cielo de Vainilla|75 ml|359990|233994|E
Creed|Irish Green Flower|100 ml|429990|279494|E
Creed|Love in White|75 ml|359990|233994|E
Creed|Millennium Empire|100 ml|429990|279494|E
Creed|Napoleon Eau de Cologne|100 ml|429990|279494|E
Creed|Napoleon's Water Edición Mejorada 2025|100 ml|429990|279494|E
Creed|Osmanthus Shadow|75 ml|359990|233994|E
Creed|Osmanthus Shadow Like Silk|75 ml|359990|233994|E
Creed|Paradise Rose (2025)|75 ml|359990|233994|E
Creed|Set de regalo Agua de Napoleón|S/D|330000|214500|E
Creed|Verde Bosque|100 ml|429990|279494|E
Creed|Viking Pirate|100 ml|429990|279494|E
Dior|Addict EDT|100 ml|169990|110494|E
Dior|Ambre Nuit Esprit de Parfum|80 ml|339990|220994|E
Dior|Cruise Collection Escale à Portofino|125 ml|199990|129994|E
Dior|Dior Homme Classic EDT|125 ml|199990|129994|E
Dior|Dior Homme EDT|125 ml|199990|129994|E
Dior|Dune|100 ml|169990|110494|E
Dior|Dune EDP|100 ml|169990|110494|E
Dior|Fahrenheit 32 (Punto de congelación)|100 ml|169990|110494|E
Dior|Heritage Oud Rose EDT|125 ml|459990|298994|E
Dior|Higher Energy (2003)|100 ml|169990|110494|E
Dior|Homme Parfum (2014)|100 ml|169990|110494|E
Dior|Homme Sport (2012)|100 ml|169990|110494|E
Dior|Hypnotic Poison EDP|100 ml|169990|110494|E
Dior|J'adore L'Or Essence (2023)|80 ml|271100|176215|V
Dior|Jasmin des Anges|125 ml|459990|298994|E
Dior|Jasmin des Anges – Heritage White Bottle|125 ml|459990|298994|E
Dior|Joy EDP|90 ml|155990|101394|E
Dior|La Collection Privée – Gris Dior (Heritage)|125 ml|459990|298994|E
Dior|Lucky Esprit de Parfum|80 ml|339990|220994|E
Dior|Miss Dior Blooming Bouquet EDP|100 ml|169990|110494|E
Dior|Miss Dior Blooming Bouquet EDT|30 ml|89990|58494|E
Dior|Miss Dior Eau de Parfum (edición lazo 23D)|100 ml|169990|110494|E
Dior|Miss Dior Haute Couture Dress Ribbon|100 ml|169990|110494|E
Dior|Miss Dior Rose Bouquet (2021)|100 ml|169990|110494|E
Dior|Miss Dior Rose Bouquet (2021)|100 ml|169990|110494|E
Dior|Miss Dior Rosewater EDP|100 ml|169990|110494|E
Dior|Poison EDP|100 ml|169990|110494|E
Dior|Rose N'Roses (2020)|100 ml|169990|110494|E
Dior|Rouge Trafalgar Esprit de Parfum|125 ml|459990|298994|E
Dior|Sauvage Eau Forte|100 ml|169990|110494|E
Dior|Sauvage Eau Forte|100 ml|169990|110494|E
Dior|Sauvage gel de ducha|250 ml|59990|38994|E
Hermès|Rose Ikebana / Hermes Noir|100 ml|369990|240494|E
Jean Paul Gaultier|Divine Essence (2025)|100 ml|147990|96194|E
Jean Paul Gaultier|Edición Coleccionista Sainte-Deux-Regard (2026)|100 ml|147990|96194|E
Jean Paul Gaultier|La Belle Intense|125 ml|155990|101394|E
Jean Paul Gaultier|La Belle Intense|125 ml|155990|101394|E
Jean Paul Gaultier|Le Male Blue Nude EDT|125 ml|155990|101394|E
Jean Paul Gaultier|Le Male Elixir|125 ml|155990|101394|E
Jean Paul Gaultier|Le Male Naked Man|125 ml|155990|101394|E
Jean Paul Gaultier|Le Male Naked Man / Paradise (2025)|125 ml|155990|101394|E
Jean Paul Gaultier|Le Male Naked Man versión mejorada (2025)|125 ml|155990|101394|E
Jean Paul Gaultier|Le Male Paradise Garden|125 ml|152990|99444|E
Jean Paul Gaultier|Naked Man Pride Edition|125 ml|155990|101394|E
Jean Paul Gaultier|Nude Stripe Edición Limitada Coleccionista|125 ml|155990|101394|E
Jean Paul Gaultier|Scandal EDT hombre|100 ml|147990|96194|E
Jean Paul Gaultier|Scandal – Hombres escandalosos (2025)|100 ml|147990|96194|E
Jean Paul Gaultier|Scandal – Piernas de una bella dama|100 ml|147990|96194|E
Jean Paul Gaultier|Scandal – Piernas de una bella dama (2025)|100 ml|147990|96194|E
Jean Paul Gaultier|Square EDP para mujer|100 ml|147990|96194|E
Jean Paul Gaultier|Ultra Male|125 ml|155990|101394|E
Louis Vuitton (LV)|Afternoon Swim|100 ml|414990|269744|E
Louis Vuitton (LV)|Apogée|100 ml|414990|269744|E
Louis Vuitton (LV)|Beach Walk|100 ml|414990|269744|E
Louis Vuitton (LV)|Benxing / Estrella fugaz|100 ml|414990|269744|E
Louis Vuitton (LV)|Cactus Garden / California Dream – Serie|100 ml|414990|269744|E
Louis Vuitton (LV)|California Dream (20th Anniversary)|100 ml|414990|269744|E
Louis Vuitton (LV)|Colección unisex LV (varios aromas)|100 ml|499990|324994|E
Louis Vuitton (LV)|Dream Chaser|100 ml|414990|269744|E
Louis Vuitton (LV)|Edición Colaboración Siyang / Peach|100 ml|414990|269744|E
Louis Vuitton (LV)|Imagination|100 ml|414990|269744|E
Louis Vuitton (LV)|Jade Wheel|100 ml|414990|269744|E
Louis Vuitton (LV)|Leyenda Lunar / Jade Wheel|100 ml|414990|269744|E
Louis Vuitton (LV)|Liaoyu / 辽域|S/D|414990|269744|E
Louis Vuitton (LV)|Melocotón Edición Limitada|100 ml|414990|269744|E
Louis Vuitton (LV)|Ombre Nomade|100 ml|599990|389994|E
Louis Vuitton (LV)|Rhapsody|S/D|414990|269744|E
Louis Vuitton (LV)|Sables Roses / serie aromática|100 ml|599990|389994|E
Louis Vuitton (LV)|Sables Roses Edición Limitada|100 ml|599990|389994|E
Louis Vuitton (LV)|Star City|100 ml|414990|269744|E
Louis Vuitton (LV)|Stellar Age (2025)|S/D|414990|269744|E
Louis Vuitton (LV)|Sur la Route|100 ml|414990|269744|E
Louis Vuitton (LV)|Symphony|S/D|599990|389994|E
Louis Vuitton (LV)|Thunderstorm|100 ml|414990|269744|E
Louis Vuitton (LV)|Tranquil Coast|100 ml|414990|269744|E
Louis Vuitton (LV)|Unlimited / Nivel Ilimitado|S/D|414990|269744|E
Maison Francis Kurkdjian|Aqua Universalis|70 ml|274000|178100|E
Maison Francis Kurkdjian|Aqua Universalis|70 ml|274000|178100|E
Maison Francis Kurkdjian|Grand Soir|70 ml|274000|178100|V
Maison Francis Kurkdjian|Grand Soir (2016)|200 ml|649990|422494|E
Maison Francis Kurkdjian|Nightless City Edición Limitada 724|70 ml|274000|178100|E
Maison Francis Kurkdjian|Nightless City Edición Limitada 724|200 ml|649990|422494|E
Maison Francis Kurkdjian|Oud Satin Mood EDP|70 ml|389990|253494|E
Maison Francis Kurkdjian|Oud Satin Mood EDP|200 ml|649990|422494|E
Maison Francis Kurkdjian|Oud Satin Mood – Ebony Silk|70 ml|389990|253494|E
Maison Francis Kurkdjian|Regreso a la Infancia|70 ml|274000|178100|E
Maison Francis Kurkdjian|À La Rose (2014)|70 ml|274000|178100|E
Maison Francis Kurkdjian|À La Rose (2014)|200 ml|649990|422494|E
Tom Ford|Amber Intrigue|100 ml|399990|259994|E
Tom Ford|Bois Marocain (2022)|50 ml|289990|188494|E
Tom Ford|Café Rose (2023)|100 ml|399990|259994|E
Tom Ford|Fucking Fabulous Edición Limitada|100 ml|469990|305494|E
Tom Ford|Fucking Fabulous Edición Limitada|100 ml|469990|305494|E
Tom Ford|Fucking Fabulous EDP|100 ml|469990|305494|E
Tom Ford|Jasmin Rouge|100 ml|399990|259994|E
Tom Ford|Mandarino di Amalfi EDP|100 ml|399990|259994|E
Tom Ford|Neroli Portofino|100 ml|469990|305494|E
Tom Ford|Neroli Portofino Oil|100 ml|469990|305494|E
Tom Ford|Rose Exposed (2025)|100 ml|399990|259994|E
Tom Ford|Santal Blush|50 ml|289990|188494|E
Tom Ford|Soleil Neige|50 ml|289990|188494|E
Tom Ford|Soleil Neige|100 ml|469990|305494|E
Tom Ford|Soleil Neige Parfum|100 ml|469990|305494|E
Tom Ford|Tobacco Oud|100 ml|469990|305494|E
Tom Ford|Tobacco Vanille|100 ml|469990|305494|E
Tom Ford|Tobacco Vanille|100 ml|469990|305494|E
Tom Ford|Vanilla Sex (2023)|50 ml|289990|188494|E
Tom Ford|Vanilla Sex (2023)|100 ml|399990|259994|E
Tom Ford|Vanilla Sex EDP|50 ml|289990|188494|E
Tom Ford|Ébène Fumé (2021)|100 ml|399990|259994|E
Valentino|Afternoon Boy|100 ml|159990|103994|E
Valentino|Behind the Seen|100 ml|159990|103994|E
Valentino|Blanco Marfil Nacido en Roma|S/D|159990|103994|E
Valentino|Born in Roma Coral Fantasy EDP|100 ml|163990|106594|E
Valentino|Born in Roma EDP – hombre|100 ml|163990|106594|E
Valentino|Born in Roma Rockstud Noir|100 ml|163990|106594|E
Valentino|Born in Roma – mujer (2025)|100 ml|163990|106594|E
Valentino|Boundless Dream|100 ml|159990|103994|E
Valentino|Club Couture (2024)|100 ml|199990|129994|E
Valentino|Dangerous Lady / Lady of the Wild|100 ml|159990|103994|E
Valentino|Disorderly Love|100 ml|159990|103994|E
Valentino|Donna Born in Roma The Gold (2024)|100 ml|179990|116994|E
Valentino|Donna Born in Roma Yellow Dream (2021)|100 ml|163990|106594|E
Valentino|Dream Girl|100 ml|159990|103994|E
Valentino|Dream Girl EDP|100 ml|159990|103994|E
Valentino|El Avaro|100 ml|159990|103994|E
Valentino|Fragancia honor a los hombres|100 ml|159990|103994|E
Valentino|Fragancia versión masculina|100 ml|159990|103994|E
Valentino|Gentleman's Delight|100 ml|159990|103994|E
Valentino|Haute Couture Club|100 ml|199990|129994|E
Valentino|Heartbeat Dialogue|100 ml|159990|103994|E
Valentino|Lady EDP|100 ml|159990|103994|E
Valentino|Lady Elegance|100 ml|159990|103994|E
Valentino|Midnight Gentleman / Mr. Unruly|100 ml|159990|103994|E
Valentino|Miss Adventure|100 ml|159990|103994|E
Valentino|Miss Donna|100 ml|159990|103994|E
Valentino|Miss Sunset|100 ml|159990|103994|E
Valentino|Motorbike Rider|100 ml|159990|103994|E
Valentino|Mr. Dark Night|100 ml|159990|103994|E
Valentino|Mr. Gold|100 ml|179990|116994|E
Valentino|Mr. Ink|100 ml|159990|103994|E
Valentino|Mr. Twilight|100 ml|159990|103994|E
Valentino|Pink Lady|100 ml|159990|103994|E
Valentino|Punk Sweetheart|100 ml|159990|103994|E
Valentino|Red Dress Rebellion|100 ml|159990|103994|E
Valentino|Rosa Blanca|100 ml|159990|103994|E
Valentino|Uomo Born in Roma The Gold (2024)|100 ml|179990|116994|E
Versace|Black Diamond|90 ml|139990|90994|E
Versace|Eau de Parfum – frasco rosa|90 ml|139990|90994|E
Versace|Eros Desert Flame|100 ml|122990|79944|E
Versace|Eros EDT – frasco rojo|100 ml|122990|79944|E
Versace|Golden Eros Pour Femme|100 ml|122990|79944|E
Versace|Green Diamond EDP (2025)|90 ml|139990|90994|E
Versace|Neptune EDT – frasco azul|100 ml|119990|77994|E
Versace|Oud Noir Pour Homme (2013)|100 ml|125990|81894|V
Versace|Pink Diamond EDP|30 ml|79990|51994|E
Versace|Purple Neptune EDP|100 ml|119990|77994|E
Versace|Versense / Heartbeat (2009)|100 ml|119990|77994|E
Versace|Yellow Diamond EDP|90 ml|139990|90994|E
Xerjoff|Accento Serie V (2019)|100 ml|339990|220994|E
Xerjoff|Cruz del Sur II|100 ml|315990|205394|E
Xerjoff|Opera (2024)|100 ml|339990|220994|E
Xerjoff|Wardasina Serie V – Rosa Exótica|100 ml|339990|220994|E
Xerjoff|Wardasina Velvet Exotic Rose|100 ml|339990|220994|E
Xerjoff|Yellow Choi|100 ml|279990|181994|E
Yves Saint Laurent|Cinema / Dream Star EDP|90 ml|176990|115044|E
Yves Saint Laurent|Couture Floral Bow (2025)|75 ml|152990|99444|E
Yves Saint Laurent|Haute Couture Leather Collection|125 ml|299990|194994|E
Yves Saint Laurent|Haute Couture Muse|125 ml|299990|194994|E
Yves Saint Laurent|Libre Berry Delight (2026)|90 ml|176990|115044|E
Yves Saint Laurent|Libre Berry Thrills (2026)|90 ml|176990|115044|E
Yves Saint Laurent|Libre Freestyle EDT|50 ml|125990|81894|E
Yves Saint Laurent|Libre Liberty Water Gold Edition|90 ml|176990|115044|E
Yves Saint Laurent|Libre Platinum Realm EDP|90 ml|176990|115044|E
Yves Saint Laurent|Y Avant EDP|100 ml|161990|105294|E
Yves Saint Laurent|Y Born Unbound EDP|100 ml|161990|105294|E
Yves Saint Laurent|Y New Pioneer Rich Essence|100 ml|161990|105294|E
Yves Saint Laurent|Y New Pioneer – Icy Cologne (2026)|100 ml|161990|105294|E
Yves Saint Laurent|Y Pioneer Frosted Bottle EDT / EDP|100 ml|161990|105294|E
Yves Saint Laurent|Y – Edición 2025|90 ml|176990|115044|E`;

const featuredNames = new Set([
  "Brit Sheer EDT",
  "Good Girl EDP",
  "Millésime Imperial EDP",
  "Sauvage EDP",
  "La Belle EDP",
  "Noir de Noir EDP",
  "Donna Born in Roma EDP",
  "Eros Parfum",
  "Erba Pura EDP",
]);

function inferGender(name: string): CatalogSeedRow["gender"] {
  const value = name.toLowerCase();
  if (/\b(femme|for women|for her|her|mujer|donna|lady|girl|miss|goddess|j'adore|divine|la belle|bright crystal)\b/.test(value)) return "Mujer";
  if (/\b(homme|uomo|for men|pour homme|male|man|masculino|hombres|men|sauvage|eros|wanted|hero|gentleman)\b/.test(value)) return "Hombre";
  return "Unisex";
}

function inferFamily(name: string): string {
  const value = name.toLowerCase();
  if (/oud|amber|ambre|tobacco|vanilla|noir|satin|spice|inciense|ebene|rose ikebana/.test(value)) return "Ámbar y especias";
  if (/rose|jasmin|flower|floral|bloom|donna|girl|divine|poison|peony|petal|pink|joy/.test(value)) return "Floral";
  if (/citrus|cologne|aqua|water|swim|blue|energy|turquoise|portofino|bergamot|fresh|versense|neptune|lemon/.test(value)) return "Cítrica y fresca";
  if (/leather|wood|bois|santal|forest|heath|sage|vetiver|oud/.test(value)) return "Amaderada";
  return "Aromática";
}

function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

const photoCatalog: Record<string, { image: string }> = originalPhotos;
const uniqueRows = new Map<string, CatalogSeedRow>();
for (const line of RAW_CATALOG.split("\n")) {
  const [brand, name, size, retail, price, availability = "E"] = line.split("|");
  if (!brand || !name || !size || !retail || !price) continue;
  const gender = inferGender(name);
  const family = inferFamily(name);
  const identity = `${brand}|${name}|${size}`.toLocaleLowerCase("es-CL");
  const description = `${name} de ${brand}, una elección sofisticada para descubrir tu próxima firma olfativa. Presentación de ${size}; disponibilidad sujeta a stock.`;
  const slug = slugify(`${brand}-${name}-${size}`);
  uniqueRows.set(identity, {
    brand,
    name,
    size,
    retailPrice: Number(retail),
    price: roundPerfumePrice(Number(price)),
    availability,
    gender,
    family,
    image: photoCatalog[slug]?.image ?? "",
    description,
    notes: [family, gender === "Unisex" ? "Estela envolvente" : "Carácter distintivo", "Consulta por asesoría olfativa"],
    featured: featuredNames.has(name),
    slug,
  });
}

export const catalogSeeds = [...uniqueRows.values()];
