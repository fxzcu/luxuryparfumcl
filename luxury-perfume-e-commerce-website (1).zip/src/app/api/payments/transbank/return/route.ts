import { and, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { confirmOrderByNumber } from "@/lib/orders";

export const runtime = "nodejs";

function apiConfig() {
  const production = process.env.TRANSBANK_ENV === "production";
  return {
    commerceCode: process.env.TRANSBANK_COMMERCE_CODE,
    apiKey: process.env.TRANSBANK_API_KEY,
    endpoint: production
      ? "https://webpay3g.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions"
      : "https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions",
  };
}

function redirect(request: NextRequest, status: string, orderNumber?: string) {
  const destination = new URL("/", process.env.NEXT_PUBLIC_SITE_URL || request.nextUrl.origin);
  destination.searchParams.set("payment", status);
  if (request.nextUrl.searchParams.get("contact") === "1") { destination.searchParams.set("contact", "1"); destination.hash = "proveedores"; }
  if (orderNumber) destination.searchParams.set("order", orderNumber);
  return NextResponse.redirect(destination, 303);
}

async function commit(request: NextRequest, token: string | null) {
  if (!token || token.length > 512) return redirect(request, "cancelled");
  const config = apiConfig();
  if (!config.commerceCode || !config.apiKey) return redirect(request, "unavailable");

  try {
    const response = await fetch(`${config.endpoint}/${encodeURIComponent(token)}`, {
      method: "PUT",
      headers: {
        "Tbk-Api-Key-Id": config.commerceCode,
        "Tbk-Api-Key-Secret": config.apiKey,
        "Content-Type": "application/json",
      },
      signal: AbortSignal.timeout(15_000),
    });
    const result = (await response.json().catch(() => ({}))) as {
      status?: string;
      response_code?: number;
      buy_order?: string;
      authorization_code?: string;
      transaction_id?: number;
      amount?: number;
    };
    if (!response.ok || !result.buy_order) return redirect(request, "failed");
    const [order] = await db
      .select({ paymentProvider: orders.paymentProvider, paymentReference: orders.paymentReference, total: orders.total })
      .from(orders)
      .where(eq(orders.orderNumber, result.buy_order))
      .limit(1);
    if (!order || order.paymentProvider !== "transbank" || order.paymentReference !== token || Number(result.amount) !== order.total) {
      return redirect(request, "failed", result.buy_order);
    }

    if (result.status === "AUTHORIZED" && result.response_code === 0) {
      const confirmation = await confirmOrderByNumber(result.buy_order, String(result.transaction_id ?? result.authorization_code ?? token));
      if (confirmation.confirmed) return redirect(request, "approved", result.buy_order);
      return redirect(request, confirmation.stockConflict ? "review" : "failed", result.buy_order);
    }

    await db
      .update(orders)
      .set({ paymentStatus: "rejected", status: "payment_failed", updatedAt: new Date() })
      .where(and(eq(orders.orderNumber, result.buy_order), eq(orders.paymentStatus, "pending")));
    return redirect(request, "failed", result.buy_order);
  } catch (error) {
    console.error("Unable to commit Transbank transaction", error);
    return redirect(request, "processing");
  }
}

export async function POST(request: NextRequest) {
  let token: string | null = request.nextUrl.searchParams.get("token_ws");
  try {
    const form = await request.formData();
    const postedToken = form.get("token_ws");
    if (typeof postedToken === "string") token = postedToken;
  } catch {
    // Transbank may call the configured return URL with query parameters.
  }
  return commit(request, token);
}

export async function GET(request: NextRequest) {
  const token = request.nextUrl.searchParams.get("token_ws");
  if (!token && request.nextUrl.searchParams.has("TBK_TOKEN")) return redirect(request, "cancelled");
  return commit(request, token);
}
