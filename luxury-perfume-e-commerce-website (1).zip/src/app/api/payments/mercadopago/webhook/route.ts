import { NextRequest, NextResponse } from "next/server";
import { confirmMercadoPagoPayment, fetchMercadoPagoPayment } from "@/lib/mercadopago";

export const runtime = "nodejs";

async function processNotification(paymentId: string | null) {
  if (!paymentId || !/^\d{1,24}$/.test(paymentId)) {
    return NextResponse.json({ received: false }, { status: 400 });
  }
  try {
    const payment = await fetchMercadoPagoPayment(paymentId);
    if (!payment) return NextResponse.json({ received: false }, { status: 503 });
    const result = await confirmMercadoPagoPayment(payment);
    return NextResponse.json({ received: true, confirmed: result.confirmed });
  } catch (error) {
    console.error("Mercado Pago webhook verification failed", error);
    return NextResponse.json({ received: false }, { status: 503 });
  }
}

export async function GET(request: NextRequest) {
  const id = request.nextUrl.searchParams.get("data.id") || request.nextUrl.searchParams.get("id");
  return processNotification(id);
}

export async function POST(request: NextRequest) {
  let id = request.nextUrl.searchParams.get("data.id") || request.nextUrl.searchParams.get("id");
  try {
    const payload = (await request.json()) as { data?: { id?: string | number }; id?: string | number };
    const postedId = payload.data?.id ?? payload.id;
    if (postedId !== undefined) id = String(postedId);
  } catch {
    // Algunos avisos de pago llegan solo con el identificador en la query.
  }
  return processNotification(id);
}
