import { asc } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { normalizeProductInput } from "@/lib/product-input";
import { requireAdmin } from "@/lib/require-admin";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  const result = await db.select().from(products).orderBy(asc(products.brand), asc(products.name));
  return NextResponse.json({ products: result });
}

export async function POST(request: NextRequest) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Datos de producto inválidos." }, { status: 400 });
  }
  const values = normalizeProductInput(body);
  if (!values) return NextResponse.json({ error: "Completa marca, nombre, tamaño, precios, stock e imagen correctamente." }, { status: 400 });
  try {
    const [created] = await db.insert(products).values(values).returning();
    return NextResponse.json({ product: created }, { status: 201 });
  } catch (error) {
    console.error("Unable to create product", error);
    return NextResponse.json({ error: "No se pudo guardar el perfume. Puede existir otro producto con el mismo nombre y tamaño." }, { status: 409 });
  }
}
