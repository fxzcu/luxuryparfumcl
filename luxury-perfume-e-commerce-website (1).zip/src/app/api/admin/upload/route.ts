import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/require-admin";

export const runtime = "nodejs";
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

function imageExtension(bytes: Buffer, mimeType: string) {
  if (mimeType === "image/jpeg" && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "jpg";
  if (mimeType === "image/png" && bytes.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]))) return "png";
  if (mimeType === "image/webp" && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "webp";
  return null;
}

export async function POST(request: NextRequest) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "No pudimos leer la fotografía." }, { status: 400 });
  }
  const file = form.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "Selecciona una fotografía." }, { status: 400 });
  if (file.size < 1 || file.size > MAX_IMAGE_BYTES) {
    return NextResponse.json({ error: "La fotografía debe pesar menos de 5 MB." }, { status: 413 });
  }
  const bytes = Buffer.from(await file.arrayBuffer());
  const extension = imageExtension(bytes, file.type);
  if (!extension) return NextResponse.json({ error: "Formato no admitido. Usa JPG, PNG o WEBP." }, { status: 415 });
  const directory = path.join(process.cwd(), "public", "uploads");
  await mkdir(directory, { recursive: true });
  const filename = `${randomUUID()}.${extension}`;
  await writeFile(path.join(directory, filename), bytes, { flag: "wx" });
  return NextResponse.json({ url: `/uploads/${filename}` }, { status: 201 });
}
