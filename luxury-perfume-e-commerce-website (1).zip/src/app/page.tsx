import Storefront from "@/components/storefront";
import { getPublicProducts } from "@/lib/catalog";
import { getPublicSupplierOffers } from "@/lib/suppliers";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [catalog, publicSuppliers] = await Promise.all([getPublicProducts(), getPublicSupplierOffers()]);
  return <Storefront products={catalog} suppliers={publicSuppliers} />;
}
