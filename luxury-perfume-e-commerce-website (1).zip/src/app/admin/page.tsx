import { cookies } from "next/headers";
import AdminPanel from "@/components/admin-panel";
import { ADMIN_COOKIE, isValidAdminToken } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const cookieStore = await cookies();
  const authenticated = isValidAdminToken(cookieStore.get(ADMIN_COOKIE)?.value);
  return <AdminPanel initialAuthenticated={authenticated} />;
}
