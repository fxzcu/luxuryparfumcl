"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import type { ContactReference } from "@/lib/supplier-bundles";
import WebpayPaymentMethod from "@/components/webpay-payment-method";

export type SupplierOffer = {
  id: number;
  name: string;
  category: string;
  logo: string;
  description: string;
  brands: string[];
  price: number | null;
  canPurchase: boolean;
  includedSuppliers: ContactReference[];
  individualTotal: number | null;
};

const currency = (value: number) => new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(value);
const savingsFor = (offer: SupplierOffer) => offer.price && offer.individualTotal ? Math.max(0, offer.individualTotal - offer.price) : 0;

function OfferIcon({ category }: { category: string }) {
  return <svg width="47" height="47" viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {category === "technology" ? <><rect x="8" y="8" width="32" height="23" rx="2"/><path d="M18 39h12M24 31v8M13 26h22"/><circle cx="24" cy="27" r=".5"/></>
    : category === "wholesale" ? <><path d="m24 5 17 9v20l-17 9-17-9V14Z"/><path d="m7 14 17 9 17-9M24 23v20M15 10l17 9v10"/></>
    : category === "bundle" ? <><path d="M7 21h34v20H7zM5 14h38v7H5zM24 14v27"/><path d="M24 14c-11 0-13-3-11-7 3-5 10 1 11 7Zm0 0c11 0 13-3 11-7-3-5-10 1-11 7Z"/></>
    : <><rect x="11" y="20" width="26" height="23" rx="3"/><path d="M18 20v-6h12v6M17 5h14v9H17zM17 27h14v9H17z"/><path d="M21 31h6"/></>}
  </svg>;
}

export default function SupplierShop({ suppliers }: { suppliers: SupplierOffer[] }) {
  const [selected, setSelected] = useState<SupplierOffer | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState<{ number: string; message: string } | null>(null);
  const [form, setForm] = useState({ name: "", email: "", contactDelivery: "email", tiktokHandle: "" });
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const singles = suppliers.filter((supplier) => supplier.category !== "bundle");
  const bundles = suppliers.filter((supplier) => supplier.category === "bundle");
  const selectedIsBundle = selected?.category === "bundle";

  useEffect(() => {
    if (!selected) return;
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busy) setSelected(null);
      if (event.key !== "Tab") return;
      const controls = dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea');
      if (!controls?.length) return;
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = overflow; window.removeEventListener("keydown", onKey); previous?.focus(); };
  }, [selected, busy]);

  function open(offer: SupplierOffer) {
    setSelected(offer);
    setSuccess(null);
    setError("");
    setBusy(false);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selected || busy) return;
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/suppliers/purchase", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, paymentProvider: "transbank", supplierId: selected.id, intent: selected.canPurchase ? "purchase" : "quote", expectedPrice: selected.price }),
      });
      const result = await response.json() as { error?: string; requestCreated?: boolean; orderNumber?: string; message?: string; provider?: string; url?: string; token?: string };
      if (!response.ok) throw new Error(result.error || "No pudimos procesar tu solicitud.");
      if (result.requestCreated) {
        setSuccess({ number: result.orderNumber || "", message: result.message || "Tu solicitud está guardada. No se realizó ningún cobro." });
        setBusy(false);
        return;
      }
      if (!result.url || !/^https:\/\//.test(result.url)) throw new Error("La pasarela no devolvió una dirección de pago válida.");
      if (result.provider === "transbank" && result.token) {
        const paymentForm = document.createElement("form");
        paymentForm.method = "POST";
        paymentForm.action = result.url;
        const token = document.createElement("input");
        token.type = "hidden"; token.name = "token_ws"; token.value = result.token;
        paymentForm.appendChild(token); document.body.appendChild(paymentForm); paymentForm.submit();
      } else throw new Error("Webpay no devolvió los datos necesarios para iniciar el pago. Inténtalo nuevamente.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No pudimos conectar. Inténtalo nuevamente.");
      setBusy(false);
    }
  }

  return <>
    <section className="supplier-shop page-shell" id="proveedores">
      <div className="section-heading supplier-shop-heading">
        <div><p className="eyebrow"><span className="eyebrow-rule" /> CONEXIONES QUE ABREN PUERTAS</p><h2>Tu próximo proveedor,<br /><em>a un contacto de distancia.</em></h2></div>
        <div className="supplier-delivery-note"><span aria-hidden="true">↗</span><div><strong>Directo a tu correo o TikTok</strong><p>Los contactos son enviados a tu correo electrónico o por TikTok después de confirmar la compra.</p></div></div>
      </div>
      <div className="supplier-offer-grid">
        {singles.map((supplier, index) => <article className={`supplier-offer-card supplier-offer-${supplier.category}`} key={supplier.id}>
          <div className="supplier-offer-top"><span className="offer-number">0{index + 1}</span><span className="offer-digital-label">CONTACTO DIGITAL</span></div>
          <div className="supplier-offer-symbol">{supplier.logo ? <img src={supplier.logo} alt="" loading="lazy" /> : <OfferIcon category={supplier.category} />}</div>
          <h3>{supplier.name}</h3><p className="supplier-offer-description">{supplier.description}</p>
          <div className="supplier-offer-tags">{supplier.brands.map((tag) => <span key={tag}>{tag}</span>)}</div>
          <div className="supplier-offer-includes"><span>✓</span> Datos de contacto del proveedor<br /><span>✓</span> Entrega por correo o TikTok<br /><span>✓</span> Sin gastos de despacho</div>
          <div className="supplier-offer-price"><span>ACCESO AL CONTACTO</span><strong>{supplier.price ? currency(supplier.price) : "Precio a consultar"}</strong></div>
          <button className="button button-dark" type="button" onClick={() => open(supplier)}>Comprar contacto <span aria-hidden="true">↗</span></button>
          <p className="supplier-offer-disclaimer">{supplier.canPurchase ? "Pago seguro · Entrega después de la confirmación" : "Confirma disponibilidad antes de pagar"}</p>
        </article>)}
      </div>
      {bundles.map((bundle) => <article className="supplier-bundle-card" key={bundle.id}>
        <div className="supplier-bundle-copy">
          <p className="eyebrow"><span className="eyebrow-rule" /> MÁS CONTACTOS, MÁS POSIBILIDADES</p>
          <h3>{bundle.name}</h3>
          <p className="supplier-bundle-description">{bundle.description}</p>
          <ul className="supplier-bundle-contents" aria-label="Proveedores incluidos en el pack">
            {bundle.includedSuppliers.map((member) => <li key={member.id}><span className="bundle-member-icon"><OfferIcon category={member.category} /></span><span>{member.name}</span></li>)}
          </ul>
          <p className="supplier-bundle-delivery">✓ Los 3 contactos por correo o TikTok <span>·</span> Sin gastos de despacho</p>
        </div>
        <div className="supplier-bundle-purchase">
          <div className="bundle-gift-symbol"><OfferIcon category="bundle" /></div>
          {savingsFor(bundle) > 0 && <span className="bundle-saving-badge">AHORRA {currency(savingsFor(bundle))}</span>}
          <span className="bundle-price-label">LOS 3 EN UNA SOLA COMPRA</span>
          {bundle.individualTotal !== null && savingsFor(bundle) > 0 && <span className="bundle-individual-price"><del>{currency(bundle.individualTotal)}</del> por separado</span>}
          <strong className="bundle-total-price">{bundle.price ? currency(bundle.price) : "Precio a consultar"}<small>CLP</small></strong>
          <button className="button button-gold bundle-buy-button" type="button" onClick={() => open(bundle)}>Comprar pack <span aria-hidden="true">↗</span></button>
          <p>{bundle.canPurchase ? "Un solo pago · Tres contactos digitales" : "Confirma disponibilidad antes de pagar"}</p>
        </div>
      </article>)}
      {!suppliers.length && <p className="supplier-offer-empty">Estamos actualizando los contactos disponibles. Vuelve a visitarnos pronto.</p>}
      <div className="supplier-how-it-works"><span><b>01</b> Elige un proveedor o el pack</span><i aria-hidden="true">→</i><span><b>02</b> Confirma tu compra</span><i aria-hidden="true">→</i><span><b>03</b> Recibe tus contactos por correo o TikTok</span></div>
      <p className="supplier-scope-note">La compra corresponde únicamente a los contactos de los proveedores. No incluye perfumes, tecnología ni otros productos físicos. Las condiciones comerciales se acuerdan directamente con cada proveedor.</p>
    </section>
    {selected && <div className="contact-modal-backdrop" onMouseDown={(event) => { if (event.currentTarget === event.target && !busy) setSelected(null); }}>
      <div className="contact-modal" ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="contact-modal-title">
        <button ref={closeRef} type="button" className="contact-modal-close" aria-label="Cerrar compra de contacto" disabled={busy} onClick={() => setSelected(null)}>×</button>
        {success ? <div className="contact-success" role="status"><span className="contact-success-icon">✓</span><p className="eyebrow">SOLICITUD GUARDADA</p><h2 id="contact-modal-title">Un nuevo contacto,<br /><em>un nuevo comienzo.</em></h2><p>{success.message}</p><div className="contact-reference">N.º de solicitud <strong>{success.number}</strong></div><button className="button button-dark" type="button" onClick={() => setSelected(null)}>Volver a proveedores <span>→</span></button></div>
        : <form onSubmit={submit}>
          <p className="eyebrow">{selectedIsBundle ? "TRES CONTACTOS · UN SOLO PACK" : "TU PRÓXIMA CONEXIÓN"}</p><h2 id="contact-modal-title">{selected.name}</h2>
          <div className="contact-modal-summary"><span>{selectedIsBundle ? "3 contactos digitales" : "1 contacto digital"} · Sin despacho</span><strong>{selected.price ? currency(selected.price) : "Precio a consultar"}</strong></div>
          {selectedIsBundle && <div className="contact-pack-summary"><strong>Tu pack incluye</strong><ul>{selected.includedSuppliers.map((member) => <li key={member.id}><span>✓</span>{member.name}</li>)}</ul>{savingsFor(selected) > 0 && <p>Ahorras {currency(savingsFor(selected))} frente a comprarlos por separado.</p>}</div>}
          {!selected.canPurchase && <p className="contact-quote-notice">Te confirmaremos la disponibilidad {selectedIsBundle ? "de los tres contactos " : ""}antes del pago. Esta solicitud no genera un cobro ni confirma una compra.</p>}
          <label className="contact-field" htmlFor="contact-name">Nombre y apellido<input id="contact-name" autoComplete="name" required minLength={2} maxLength={120} value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} /></label>
          <label className="contact-field" htmlFor="contact-email">Correo electrónico<input id="contact-email" type="email" autoComplete="email" required maxLength={180} placeholder="tu@correo.cl" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} /><small>Lo utilizaremos para la confirmación de tu solicitud o compra.</small></label>
          <fieldset className="contact-channel"><legend>¿Dónde quieres recibir {selectedIsBundle ? "tus 3 contactos" : "el contacto"}?</legend><div>
            <label className={form.contactDelivery === "email" ? "selected" : ""}><input type="radio" name="contactDelivery" value="email" checked={form.contactDelivery === "email"} onChange={() => setForm({ ...form, contactDelivery: "email" })} /><span>✉</span><strong>Correo electrónico</strong></label>
            <label className={form.contactDelivery === "tiktok" ? "selected" : ""}><input type="radio" name="contactDelivery" value="tiktok" checked={form.contactDelivery === "tiktok"} onChange={() => setForm({ ...form, contactDelivery: "tiktok" })} /><span>♪</span><strong>TikTok</strong></label>
          </div></fieldset>
          {form.contactDelivery === "tiktok" && <label className="contact-field" htmlFor="contact-tiktok">Tu usuario de TikTok<input id="contact-tiktok" required pattern="@?[a-zA-Z0-9_.]{2,24}" maxLength={25} placeholder="@tuusuario" value={form.tiktokHandle} onChange={(event) => setForm({ ...form, tiktokHandle: event.target.value })} /><small>Activa tus mensajes directos. La entrega por TikTok la realiza nuestro equipo de forma manual.</small></label>}
          {selected.canPurchase && <WebpayPaymentMethod />}
          {error && <p className="contact-error" role="alert">{error}</p>}
          <p className="contact-privacy">Usaremos tus datos para gestionar esta solicitud y entregar {selectedIsBundle ? "los tres contactos adquiridos" : "el contacto adquirido"}. No incluye mercancía física.</p>
          <button className="button button-dark contact-submit" disabled={busy} type="submit">{busy ? "Procesando…" : selected.canPurchase ? `Pagar ${currency(selected.price!)} con Webpay` : "Solicitar compra sin cobro"}<span aria-hidden="true">→</span></button>
          <p className="contact-modal-foot">Los contactos se entregan solo después de confirmar la compra.</p>
        </form>}
      </div>
    </div>}
  </>;
}
