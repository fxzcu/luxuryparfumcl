import styles from "./webpay-payment-method.module.css";

/** The only payment method offered for new purchases. No selector is necessary. */
export default function WebpayPaymentMethod() {
  return (
    <fieldset className={`${styles.method} webpay-payment-method`}>
      <legend>Medio de pago</legend>
      <div className={styles.card}>
        <span className={styles.check} aria-hidden="true">✓</span>
        <span className={styles.brand} aria-label="Webpay Plus">webpay<span>plus</span></span>
        <div className={styles.details}>
          <strong>Webpay Plus · Transbank</strong>
          <span>Tarjetas de débito y crédito</span>
        </div>
      </div>
      <p className={styles.caption}>Completarás el pago en el sitio oficial de Webpay. No almacenamos datos de tu tarjeta.</p>
    </fieldset>
  );
}
