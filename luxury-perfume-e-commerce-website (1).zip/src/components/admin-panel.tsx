"use client";

import Link from "next/link";
import PerfumePhoto from "@/components/perfume-photo";
import { useEffect, useState, type FormEvent } from "react";

type AdminProduct = {
  id: number; slug: string; brand: string; name: string; size: string; price: number; retailPrice: number; stock: number;
  availability: string; gender: string; family: string; image: string; description: string; notes: string[]; featured: boolean; active: boolean;
};
type AdminSupplier = { id: number; name: string; category: string; price: number | null; logo: string; description: string; brands: string[]; contact: string; active: boolean; bundleSupplierIds: number[] };
type AdminOrder = {
  id: number; orderNumber: string; total: number; paymentProvider: string; paymentStatus: string; status: string;
  shipmentStatus: string; fulfillment: string; createdAt: string; customerName: string | null; customerEmail: string | null;
  contactDelivery: string; tiktokHandle: string; confirmationEmailSentAt: string | null; items: { name: string; supplierId?: number; includedContactNames?: string[] }[];
};
type ProductForm = {
  brand: string; name: string; size: string; price: string; retailPrice: string; stock: string; gender: string;
  family: string; image: string; description: string; notes: string; featured: boolean; active: boolean;
};
type SupplierForm = { name: string; category: string; price: string; logo: string; description: string; brands: string; contact: string; active: boolean; bundleSupplierIds: number[] };
type Stats = { products: number; orders: number; paidOrders: number; revenue: number; lowStock: number };

const blankProduct: ProductForm = { brand: "", name: "", size: "100 ml", price: "", retailPrice: "", stock: "8", gender: "Unisex", family: "Aromática", image: "", description: "", notes: "", featured: false, active: true };
const blankSupplier: SupplierForm = { name: "", category: "perfume", price: "", logo: "", description: "", brands: "", contact: "", active: true, bundleSupplierIds: [] };
const bundleSlots = [{ category: "technology", label: "Tecnología" }, { category: "perfume", label: "Perfumes" }, { category: "wholesale", label: "Perfumes al por mayor" }];
const money = (amount: number) => new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(amount);

async function readJson<T>(response: Response): Promise<T & { error?: string }> {
  const body = await response.json().catch(() => ({}));
  if (response.status === 401) throw new Error("La sesión expiró. Inicia sesión nuevamente.");
  if (!response.ok) throw new Error(body.error || "No pudimos completar la operación.");
  return body as T & { error?: string };
}

export default function AdminPanel({ initialAuthenticated }: { initialAuthenticated: boolean }) {
  const [authenticated, setAuthenticated] = useState(initialAuthenticated);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [tab, setTab] = useState<"overview" | "products" | "orders" | "suppliers">("overview");
  const [products, setProducts] = useState<AdminProduct[]>([]);
  const [suppliers, setSuppliers] = useState<AdminSupplier[]>([]);
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [stats, setStats] = useState<Stats>({ products: 0, orders: 0, paidOrders: 0, revenue: 0, lowStock: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [productEditor, setProductEditor] = useState(false);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [productForm, setProductForm] = useState<ProductForm>(blankProduct);
  const [supplierEditor, setSupplierEditor] = useState(false);
  const [editingSupplierId, setEditingSupplierId] = useState<number | null>(null);
  const [supplierForm, setSupplierForm] = useState<SupplierForm>(blankSupplier);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState("");

  async function loadDashboard() {
    setLoading(true);
    setError("");
    try {
      const [overviewResponse, productResponse, supplierResponse] = await Promise.all([
        fetch("/api/admin/overview", { cache: "no-store" }),
        fetch("/api/admin/products", { cache: "no-store" }),
        fetch("/api/admin/suppliers", { cache: "no-store" }),
      ]);
      const [overview, productData, supplierData] = await Promise.all([
        readJson<{ stats: Stats; orders: AdminOrder[] }>(overviewResponse),
        readJson<{ products: AdminProduct[] }>(productResponse),
        readJson<{ suppliers: AdminSupplier[] }>(supplierResponse),
      ]);
      setStats(overview.stats);
      setOrders(overview.orders);
      setProducts(productData.products);
      setSuppliers(supplierData.suppliers);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Error al cargar los datos del panel.");
      if (loadError instanceof Error && loadError.message.includes("sesión expiró")) setAuthenticated(false);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (authenticated) void loadDashboard();
  }, [authenticated]);

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoginError("");
    const response = await fetch("/api/admin/session", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password }) });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setLoginError(result.error || "No pudimos iniciar sesión.");
      return;
    }
    setPassword("");
    setAuthenticated(true);
  }

  async function logout() {
    await fetch("/api/admin/session", { method: "DELETE" });
    setAuthenticated(false);
    setProducts([]);
    setOrders([]);
    setSuppliers([]);
  }

  async function uploadImage(file: File | undefined, destination: "product" | "supplier") {
    if (!file) return;
    setUploading(true);
    setError("");
    try {
      const data = new FormData();
      data.append("file", file);
      const result = await readJson<{ url: string }>(await fetch("/api/admin/upload", { method: "POST", body: data }));
      if (destination === "product") setProductForm((current) => ({ ...current, image: result.url }));
      else setSupplierForm((current) => ({ ...current, logo: result.url }));
      setNotice("Fotografía cargada correctamente.");
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : "No se pudo cargar la fotografía.");
    } finally {
      setUploading(false);
    }
  }

  function newProduct() {
    setEditingProductId(null);
    setProductForm(blankProduct);
    setError("");
    setProductEditor(true);
  }

  function editProduct(product: AdminProduct) {
    setEditingProductId(product.id);
    setProductForm({
      brand: product.brand, name: product.name, size: product.size, price: String(product.price), retailPrice: String(product.retailPrice),
      stock: String(product.stock), gender: product.gender, family: product.family, image: product.image,
      description: product.description, notes: product.notes.join(", "), featured: product.featured, active: product.active,
    });
    setError("");
    setProductEditor(true);
  }

  async function saveProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const payload = {
      ...productForm,
      price: Number(productForm.price), retailPrice: Number(productForm.retailPrice), stock: Number(productForm.stock),
      notes: productForm.notes.split(",").map((note) => note.trim()).filter(Boolean),
    };
    try {
      const response = await fetch(editingProductId ? `/api/admin/products/${editingProductId}` : "/api/admin/products", {
        method: editingProductId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      await readJson<{ product: AdminProduct }>(response);
      setProductEditor(false);
      setNotice(editingProductId ? "Perfume actualizado." : "Perfume agregado al catálogo.");
      await loadDashboard();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "No se pudo guardar el perfume.");
    }
  }

  async function deleteProduct(product: AdminProduct) {
    if (!window.confirm(`¿Eliminar ${product.brand} · ${product.name} del catálogo?`)) return;
    try {
      await readJson<{ deleted: boolean }>(await fetch(`/api/admin/products/${product.id}`, { method: "DELETE" }));
      setNotice("Perfume eliminado.");
      await loadDashboard();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "No se pudo eliminar el perfume.");
    }
  }

  function editSupplier(supplier?: AdminSupplier) {
    setEditingSupplierId(supplier?.id ?? null);
    setSupplierForm(supplier ? { name: supplier.name, category: supplier.category, price: supplier.price === null ? "" : String(supplier.price), logo: supplier.logo, description: supplier.description, brands: supplier.brands.join(", "), contact: supplier.contact, active: supplier.active, bundleSupplierIds: supplier.category === "bundle" ? bundleSlots.map((slot) => supplier.bundleSupplierIds.find((id) => suppliers.some((item) => item.id === id && item.category === slot.category)) ?? 0) : [] } : blankSupplier);
    setError("");
    setSupplierEditor(true);
  }

  function selectSupplierCategory(category: string) {
    const bundleSupplierIds = category === "bundle"
      ? bundleSlots.map((slot) => suppliers.find((item) => item.active && item.category === slot.category && item.id !== editingSupplierId)?.id ?? 0)
      : [];
    setSupplierForm({ ...supplierForm, category, bundleSupplierIds });
  }

  async function saveSupplier(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const payload = { ...supplierForm, price: supplierForm.price.trim() ? Number(supplierForm.price) : null, brands: supplierForm.brands.split(",").map((brand) => brand.trim()).filter(Boolean) };
    try {
      const response = await fetch(editingSupplierId ? `/api/admin/suppliers/${editingSupplierId}` : "/api/admin/suppliers", {
        method: editingSupplierId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      await readJson<{ supplier: AdminSupplier }>(response);
      setSupplierEditor(false);
      setNotice(editingSupplierId ? "Proveedor actualizado." : "Proveedor incorporado.");
      await loadDashboard();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "No se pudo guardar el proveedor.");
    }
  }

  async function deleteSupplier(supplier: AdminSupplier) {
    if (!window.confirm(`¿Eliminar a ${supplier.name} de proveedores?`)) return;
    try {
      await readJson<{ deleted: boolean }>(await fetch(`/api/admin/suppliers/${supplier.id}`, { method: "DELETE" }));
      setNotice("Proveedor retirado de la tienda; se conservan los datos de las compras existentes.");
      await loadDashboard();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "No se pudo eliminar el proveedor.");
    }
  }

  async function updateShipment(order: AdminOrder, shipmentStatus: string) {
    setError("");
    try {
      await readJson<{ order: AdminOrder }>(await fetch(`/api/admin/orders/${order.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ shipmentStatus }),
      }));
      setNotice(`Estado de despacho actualizado para ${order.orderNumber}.`);
      await loadDashboard();
    } catch (updateError) {
      setError(updateError instanceof Error ? updateError.message : "No se pudo actualizar el despacho.");
    }
  }

  async function deliverContact(order: AdminOrder) {
    setError("");
    try {
      await readJson<{ sent: boolean }>(await fetch(`/api/admin/orders/${order.id}/deliver`, { method: "POST" }));
      setNotice(`Contacto enviado al correo del pedido ${order.orderNumber}.`);
      await loadDashboard();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No se pudo enviar el contacto."); }
  }

  const matchingProducts = products.filter((product) => `${product.brand} ${product.name}`.toLocaleLowerCase("es-CL").includes(search.toLocaleLowerCase("es-CL")));

  if (!authenticated) return (
    <main className="admin-login-page">
      <Link className="admin-back-link" href="/">← Volver a la tienda</Link>
      <section className="admin-login-card"><span className="admin-login-monogram">LP</span><p className="admin-kicker">LUXURY PARFUM CL</p><h1>Un espacio<br /><em>reservado.</em></h1><p className="admin-login-copy">Acceso privado para administrar tu tienda.</p><form onSubmit={login}><label>Contraseña de administrador<input type="password" required autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} /></label>{loginError && <p className="admin-error">{loginError}</p>}<button className="admin-primary-button" type="submit">Ingresar al panel <span>→</span></button></form><p className="admin-login-foot">Sesión segura · Luxury Parfum CL</p></section>
    </main>
  );

  return (
    <main className="admin-shell">
      <aside className="admin-sidebar"><a href="/" className="admin-sidebar-brand"><span className="brand-monogram">LP</span><span><strong>LUXURY PARFUM</strong><small>ADMINISTRACIÓN</small></span></a><div className="admin-sidebar-label">TIENDA</div><nav className="admin-nav">
        <button className={tab === "overview" ? "is-active" : ""} type="button" onClick={() => setTab("overview")}><span>◈</span> Resumen</button>
        <button className={tab === "products" ? "is-active" : ""} type="button" onClick={() => setTab("products")}><span>◇</span> Perfumes <small>{stats.products}</small></button>
        <button className={tab === "orders" ? "is-active" : ""} type="button" onClick={() => setTab("orders")}><span>▤</span> Pedidos <small>{stats.orders}</small></button>
        <button className={tab === "suppliers" ? "is-active" : ""} type="button" onClick={() => setTab("suppliers")}><span>⌁</span> Proveedores <small>{suppliers.length}</small></button>
      </nav><div className="admin-sidebar-bottom"><a href="/" target="_blank">↗ Ver tienda</a><button type="button" onClick={logout}>Cerrar sesión <span>↗</span></button></div></aside>
      <section className="admin-main"><header className="admin-topbar"><div><span>OPERACIONES</span><strong>/ {tab === "overview" ? "Resumen" : tab === "products" ? "Perfumes" : tab === "orders" ? "Pedidos" : "Proveedores"}</strong></div><div className="admin-user"><span>LP</span><div><strong>Administración</strong><small>Luxury Parfum CL</small></div><button type="button" onClick={logout}>Salir</button></div></header>
        <div className="admin-content"><div className="admin-page-heading"><div><p className="admin-kicker">PANEL DE CONTROL · CHILE</p><h1>{tab === "overview" ? "Resumen de la tienda" : tab === "products" ? "Catálogo de perfumes" : tab === "orders" ? "Pedidos, solicitudes y entregas" : "Red de proveedores"}</h1><p>Gestiona la operación de Luxury Parfum CL desde un solo lugar.</p></div><button className="admin-refresh" type="button" onClick={() => void loadDashboard()}>↻ Actualizar datos</button></div>
          {error && !productEditor && !supplierEditor && <div className="admin-alert admin-alert-error">{error}<button type="button" onClick={() => setError("")}>×</button></div>}
          {notice && <div className="admin-alert admin-alert-success">✓ {notice}<button type="button" onClick={() => setNotice("")}>×</button></div>}
          {loading && <div className="admin-loading">Actualizando datos del negocio…</div>}
          {tab === "overview" && <><div className="admin-stats-grid"><article><span>INGRESOS CONFIRMADOS</span><strong>{money(stats.revenue)}</strong><small>Solo pagos aprobados</small><b>↗</b></article><article><span>PEDIDOS Y SOLICITUDES</span><strong>{stats.orders}</strong><small>{stats.paidOrders} con pago confirmado</small><b>▤</b></article><article><span>PRODUCTOS ACTIVOS</span><strong>{stats.products}</strong><small>En el catálogo público</small><b>◇</b></article><article className={stats.lowStock ? "is-warning" : ""}><span>STOCK POR REVISAR</span><strong>{stats.lowStock}</strong><small>Menos de 4 unidades</small><b>⌁</b></article></div><section className="admin-card"><div className="admin-card-heading"><div><p className="admin-kicker">ACTIVIDAD RECIENTE</p><h2>Últimos pedidos</h2></div><button type="button" onClick={() => setTab("orders")}>Ver todos →</button></div><OrderTable orders={orders.slice(0, 7)} onShipment={updateShipment} onDeliver={deliverContact} /></section><section className="admin-card admin-note-card"><span>✦</span><div><strong>Confirma el inventario real antes de abrir ventas.</strong><p>El catálogo importado trae existencias iniciales provisionales. El stock solo se descuenta cuando la pasarela confirma el pago; nunca almacenes números de tarjetas en este panel.</p></div></section></>}
          {tab === "products" && <section className="admin-card"><div className="admin-card-heading"><div><p className="admin-kicker">INVENTARIO</p><h2>{products.length} perfumes</h2></div><button className="admin-primary-button admin-small-button" type="button" onClick={newProduct}>＋ Agregar perfume</button></div><div className="admin-table-toolbar"><label>⌕ <input placeholder="Buscar por marca o nombre" value={search} onChange={(event) => setSearch(event.target.value)} /></label><span>{matchingProducts.length} resultados</span></div><div className="admin-product-list">{matchingProducts.slice(0, 100).map((product) => <article className={`admin-product-row ${!product.active ? "is-inactive" : ""}`} key={product.id}><PerfumePhoto product={product} className="admin-original-photo" /><div className="admin-product-ident"><span>{product.brand}</span><strong>{product.name}</strong><small>{product.size} · {product.gender} · {product.active ? "Visible" : "Oculto"}</small></div><div className="admin-product-price"><strong>{money(product.price)}</strong><del>{money(product.retailPrice)}</del></div><div className={`admin-stock ${product.stock < 4 ? "is-low" : ""}`}><strong>{product.stock}</strong><small>unidades</small></div><button className="admin-row-action" type="button" onClick={() => editProduct(product)}>Editar</button><button className="admin-delete-action" type="button" onClick={() => void deleteProduct(product)} aria-label={`Eliminar ${product.name}`}>×</button></article>)}</div>{matchingProducts.length > 100 && <p className="admin-results-note">Mostrando 100 coincidencias. Usa la búsqueda para acotar.</p>}</section>}
          {tab === "orders" && <section className="admin-card"><div className="admin-card-heading"><div><p className="admin-kicker">VENTAS</p><h2>{orders.length} pedidos recientes</h2></div></div><OrderTable orders={orders} onShipment={updateShipment} onDeliver={deliverContact} /></section>}
          {tab === "suppliers" && <section className="admin-card"><div className="admin-card-heading"><div><p className="admin-kicker">CONTACTOS DIGITALES</p><h2>{suppliers.length} proveedores</h2></div><button className="admin-primary-button admin-small-button" type="button" onClick={() => editSupplier()}>＋ Agregar proveedor</button></div>{suppliers.length ? <div className="admin-supplier-list"><p className="admin-contact-settings-note">Los precios están definidos: tecnología $11.990, perfumes $10.990, mayorista $12.990 y pack de los tres $19.990. El pack utiliza los contactos privados de los proveedores vinculados; no debes copiarlos. Mientras falte algún contacto, se guarda una solicitud sin cobro. La entrega es por correo o manualmente por TikTok.</p>{suppliers.map((supplier) => <article className="admin-supplier-row" key={supplier.id}><div className="admin-supplier-mark">{supplier.logo ? <img src={supplier.logo} alt="" /> : supplier.name.slice(0, 2).toUpperCase()}</div><div><strong>{supplier.name}</strong><p>{supplier.description}</p><small>{supplier.price ? money(supplier.price) : "Precio pendiente"} · {supplier.category === "bundle" ? `${supplier.bundleSupplierIds.length} contactos vinculados` : supplier.contact ? "Contacto privado configurado" : "Falta configurar el contacto"}</small></div><span className={supplier.active ? "admin-visible" : "admin-hidden"}>{supplier.active ? "Público" : "Oculto"}</span><button type="button" onClick={() => editSupplier(supplier)}>Editar</button><button className="admin-delete-action" type="button" onClick={() => void deleteSupplier(supplier)} aria-label={`Eliminar ${supplier.name}`}>×</button></article>)}</div> : <div className="admin-empty-state"><span>⌁</span><h3>Tu red comienza aquí</h3><p>Agrega distribuidores verificados para que aparezcan en la sección pública de proveedores.</p><button className="admin-primary-button admin-small-button" type="button" onClick={() => editSupplier()}>Agregar primer proveedor</button></div>}</section>}
        </div>
      </section>

      {productEditor && <div className="admin-modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && setProductEditor(false)}><form className="admin-editor-modal" onSubmit={saveProduct}><div className="admin-modal-heading"><div><p className="admin-kicker">CATÁLOGO · PERFUMERÍA</p><h2>{editingProductId ? "Editar perfume" : "Agregar perfume"}</h2></div><button type="button" onClick={() => setProductEditor(false)}>×</button></div><div className="admin-form-grid"><label>Marca<input required value={productForm.brand} onChange={(event) => setProductForm({ ...productForm, brand: event.target.value })} /></label><label>Nombre del perfume<input required value={productForm.name} onChange={(event) => setProductForm({ ...productForm, name: event.target.value })} /></label><label>Tamaño<input required placeholder="100 ml" value={productForm.size} onChange={(event) => setProductForm({ ...productForm, size: event.target.value })} /></label><label>Precio de venta · CLP<input required type="number" min="0" step="1" value={productForm.price} onChange={(event) => setProductForm({ ...productForm, price: event.target.value })} /></label><label>Precio de referencia · CLP<input required type="number" min="0" step="1" value={productForm.retailPrice} onChange={(event) => setProductForm({ ...productForm, retailPrice: event.target.value })} /></label><label>Unidades en stock<input required type="number" min="0" step="1" value={productForm.stock} onChange={(event) => setProductForm({ ...productForm, stock: event.target.value })} /></label><label>Género<select value={productForm.gender} onChange={(event) => setProductForm({ ...productForm, gender: event.target.value })}><option>Mujer</option><option>Hombre</option><option>Unisex</option></select></label><label>Familia olfativa<input required value={productForm.family} onChange={(event) => setProductForm({ ...productForm, family: event.target.value })} /></label><label className="admin-full-span">Fotografía del producto<div className="admin-upload-row"><input value={productForm.image} onChange={(event) => setProductForm({ ...productForm, image: event.target.value })} placeholder="/uploads/foto.jpg o https://..." /><label className="admin-file-button">{uploading ? "Subiendo…" : "Subir archivo"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={uploading} onChange={(event) => void uploadImage(event.target.files?.[0], "product")} /></label></div><small>JPG, PNG o WEBP · Máximo 5 MB</small></label><label className="admin-full-span">Descripción<textarea rows={3} value={productForm.description} onChange={(event) => setProductForm({ ...productForm, description: event.target.value })} /></label><label className="admin-full-span">Acordes / notas separadas por comas<input value={productForm.notes} onChange={(event) => setProductForm({ ...productForm, notes: event.target.value })} /></label><label className="admin-check"><input type="checkbox" checked={productForm.featured} onChange={(event) => setProductForm({ ...productForm, featured: event.target.checked })} /> Destacar en portada</label><label className="admin-check"><input type="checkbox" checked={productForm.active} onChange={(event) => setProductForm({ ...productForm, active: event.target.checked })} /> Visible en la tienda</label></div>{error && <p className="admin-error">{error}</p>}<div className="admin-modal-actions"><button className="admin-secondary-button" type="button" onClick={() => setProductEditor(false)}>Cancelar</button><button className="admin-primary-button" type="submit">Guardar perfume <span>→</span></button></div></form></div>}

      {supplierEditor && <div className="admin-modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && setSupplierEditor(false)}><form className="admin-editor-modal admin-supplier-editor" onSubmit={saveSupplier}><div className="admin-modal-heading"><div><p className="admin-kicker">RED COMERCIAL</p><h2>{editingSupplierId ? "Editar proveedor" : "Agregar proveedor"}</h2></div><button type="button" onClick={() => setSupplierEditor(false)}>×</button></div><div className="admin-form-grid"><label>Nombre del proveedor<input required value={supplierForm.name} onChange={(event) => setSupplierForm({ ...supplierForm, name: event.target.value })} /></label><label>Precio del contacto · CLP<input type="number" min="1" step="1" placeholder="Sin precio: permite solicitar compra" value={supplierForm.price} onChange={(event) => setSupplierForm({ ...supplierForm, price: event.target.value })} /><small>Deja vacío para recibir solicitudes sin cobro.</small></label><label>Categoría<select value={supplierForm.category} onChange={(event) => selectSupplierCategory(event.target.value)}><option value="technology">Tecnología</option><option value="perfume">Perfumes</option><option value="wholesale">Perfumes al por mayor</option><option value="bundle">Pack de los 3 proveedores</option></select></label>{supplierForm.category === "bundle" ? <fieldset className="admin-bundle-members"><legend>Los 3 proveedores del pack</legend><p>El comprador recibe estos tres contactos con un solo pago. Completa la información privada en cada proveedor individual.</p>{bundleSlots.map((slot, index) => <label key={slot.category}>{slot.label}<select required value={supplierForm.bundleSupplierIds[index] || ""} onChange={(event) => { const ids = [...supplierForm.bundleSupplierIds]; ids[index] = Number(event.target.value); setSupplierForm({ ...supplierForm, bundleSupplierIds: ids }); }}><option value="">Selecciona un proveedor</option>{suppliers.filter((item) => item.category === slot.category && item.id !== editingSupplierId).map((item) => <option key={item.id} value={item.id}>{item.name}{!item.active ? " (oculto)" : ""}</option>)}</select></label>)}</fieldset> : <label className="admin-full-span">Contacto privado · Solo para compradores<textarea rows={4} maxLength={4000} placeholder="Nombre del proveedor, correo, teléfono y/o enlace. Esta información nunca aparece en la tienda pública." value={supplierForm.contact} onChange={(event) => setSupplierForm({ ...supplierForm, contact: event.target.value })} /><small>Se entrega por correo después del pago confirmado o manualmente por TikTok. Completa precio y contacto para habilitar el pago.</small></label>}<label className="admin-full-span">Descripción<textarea rows={3} required value={supplierForm.description} onChange={(event) => setSupplierForm({ ...supplierForm, description: event.target.value })} /></label><label className="admin-full-span">Etiquetas o especialidades<input placeholder="Perfumería, Venta mayorista, Tecnología" value={supplierForm.brands} onChange={(event) => setSupplierForm({ ...supplierForm, brands: event.target.value })} /></label><label className="admin-full-span">Logotipo<div className="admin-upload-row"><input value={supplierForm.logo} onChange={(event) => setSupplierForm({ ...supplierForm, logo: event.target.value })} placeholder="/uploads/logo.png o https://..." /><label className="admin-file-button">{uploading ? "Subiendo…" : "Subir archivo"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={uploading} onChange={(event) => void uploadImage(event.target.files?.[0], "supplier")} /></label></div><small>Nombre, descripción, etiquetas, precio y logotipo son públicos. El contacto es privado.</small></label><label className="admin-check"><input type="checkbox" checked={supplierForm.active} onChange={(event) => setSupplierForm({ ...supplierForm, active: event.target.checked })} /> Visible públicamente</label></div>{error && <p className="admin-error">{error}</p>}<div className="admin-modal-actions"><button className="admin-secondary-button" type="button" onClick={() => setSupplierEditor(false)}>Cancelar</button><button className="admin-primary-button" type="submit">Guardar proveedor <span>→</span></button></div></form></div>}
    </main>
  );
}

function OrderTable({ orders, onShipment, onDeliver }: { orders: AdminOrder[]; onShipment: (order: AdminOrder, shipment: string) => void; onDeliver: (order: AdminOrder) => void }) {
  if (!orders.length) return <div className="admin-table-empty">Todavía no hay pedidos ni solicitudes.</div>;
  return <div className="admin-table-scroll"><table className="admin-orders-table"><thead><tr><th>PEDIDO / SOLICITUD</th><th>CLIENTE</th><th>FECHA</th><th>TOTAL</th><th>PAGO</th><th>ENTREGA</th></tr></thead><tbody>{orders.map((order) => {
    const digital = order.fulfillment === "digital";
    const quote = order.status === "awaiting_quote";
    return <tr key={order.id}>
      <td><strong>{order.orderNumber}</strong><small>{order.items?.map((item) => item.name).join(" · ")}</small>{order.items?.some((item) => (item.includedContactNames?.length ?? 0) > 1) && <small>Incluye: {order.items.flatMap((item) => item.includedContactNames ?? []).join(" · ")}</small>}<small>{digital ? "Contacto digital" : order.fulfillment === "pickup" ? "Retiro coordinado" : "A domicilio · 14 a 18 días"}</small></td>
      <td>{order.customerName || "—"}<small>{order.customerEmail || ""}</small>{digital && <small>Canal: {order.contactDelivery === "tiktok" ? "TikTok" : "Correo electrónico"}</small>}{digital && order.tiktokHandle && <a className="admin-contact-link" href={`https://www.tiktok.com/${encodeURIComponent(order.tiktokHandle)}`} target="_blank" rel="noreferrer">{order.tiktokHandle} ↗</a>}</td>
      <td>{new Date(order.createdAt).toLocaleDateString("es-CL", { day: "2-digit", month: "short", year: "numeric" })}</td>
      <td>{quote ? "Por cotizar" : money(order.total)}</td>
      <td><span className={`payment-pill payment-${order.paymentStatus}`}>{quote ? "Solicitud · sin cobro" : order.paymentStatus === "paid" ? "Confirmado" : order.paymentStatus === "paid_review" ? "Aprobado · revisión" : order.paymentStatus === "pending" ? "Pendiente" : order.paymentStatus}</span><small>{order.paymentProvider === "quotation" ? "Confirmar precio con el cliente" : order.paymentProvider === "transbank" ? "Webpay Plus" : order.paymentProvider === "mercadopago" ? "Mercado Pago (histórico)" : "Pago anterior"}</small></td>
      <td>{order.paymentStatus === "paid" ? <><select aria-label={`Estado de entrega de ${order.orderNumber}`} value={order.shipmentStatus} onChange={(event) => onShipment(order, event.target.value)}><option value="not_started">Por preparar</option><option value="preparing">Preparando</option>{!digital && <option value="in_transit">En camino</option>}<option value="delivered">Entregado</option></select>{digital && order.contactDelivery === "email" && !order.confirmationEmailSentAt && <button className="admin-delivery-action" type="button" onClick={() => onDeliver(order)}>Enviar contacto por correo</button>}{digital && order.contactDelivery === "tiktok" && <small>Enviar manualmente por TikTok</small>}</> : <span className="shipment-wait">{quote ? "Coordinar la compra" : "Esperando pago"}</span>}</td>
    </tr>;
  })}</tbody></table></div>;
}
