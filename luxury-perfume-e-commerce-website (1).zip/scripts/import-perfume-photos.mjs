import fs from "node:fs/promises";
import sharp from "sharp";

// Sources are public product catalogs fetched during the verified photo import.
const sourceFile = process.argv[2] || "/tmp/lpc-photo-sources.json";
const sources = JSON.parse(await fs.readFile(sourceFile, "utf8"));
sources.push(...[
  ["50", "12709338", "7594925973747420"], ["100", "12709339", "6504925973791697"],
].map(([size, id, imageId]) => ({
  title: `Tom Ford Soleil Neige EDP ${size} ml`, vendor: "Tom Ford", handle: `tom-ford-soleil-neige-${size}ml`,
  source: `https://www.lookfantastic.com/p/tom-ford-soleil-neige-eau-de-parfum-spray-30ml/13956175/?variation=${id}`,
  images: [{ src: `https://static.thcdn.com/productimg/original/${id}-${imageId}.jpg` }], variants: [],
})));
const catalogFile = await fs.readFile("src/lib/catalog-data.ts", "utf8");
const rows = catalogFile.split("String.raw`")[1].split("`;")[0].split("\n").filter(Boolean).map((line) => {
  const [brand, name, size] = line.split("|");
  return { brand, name, size };
});
const normalize = (value) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
const slug = (value) => normalize(value).replaceAll(" ", "-");
const concentration = (value) => {
  const text = normalize(value);
  if (/\bedp\b|eau de parfum/.test(text)) return "edp";
  if (/\bedt\b|eau de toilette/.test(text)) return "edt";
  if (/\bparfum\b/.test(text)) return "parfum";
  return "";
};
const baseName = (value, brand) => {
  let text = normalize(value).replaceAll(normalize(brand.replace(/\s*\(LV\)/i, "")), " ");
  text = text.replace(/\beau de parfum\b|\beau de toilette\b|\bfor (her|him|men|women)\b|\bpour (homme|femme)\b/g, " ");
  text = text.replace(/\d+\s*ml\b|\b(edp|edt|parfum|men|women|hombre|mujer|nuevo|recargable|spray)\b/g, " ");
  if (brand === "Xerjoff") text = text.replace(/\bxj\b|\b1861\b|\bshooting stars\b/g, " ").replace(/torino\s*21/, "torino21");
  if (brand === "Jean Paul Gaultier") text = text.replace(/^\s*gaultier\s+/, " ");
  return text.replace(/\s+/g, " ").trim() || "signature-homme";
};
const direct = {
  "Tom Ford|Noir de Noir EDP": { title: "TOM FORD Noir de Noir Eau de Parfum 100ml", source: "https://www.lookfantastic.com/p/tom-ford-noir-de-noir-eau-de-parfum-spray-100ml/12709330/", images: [{ src: "https://static.thcdn.com/productimg/original/12709330-2105348403140301.jpg" }], variants: [] },
};
const handleOverrides = {
  "Burberry|My Burberry Black EDP": "my-burberry-black-parfum-90-ml",
  "Versace|Dylan Purple EDP": "versace-dylan-purple-pour-femme-edp-100-ml-vers112",
};
const mapping = {};
const missing = [];
const candidates = [];
const unverifiedConcentrations = new Set(["Dior|Miss Dior Blooming Bouquet EDP", "Versace|Yellow Diamond EDP"]);
for (const row of rows) {
  if (unverifiedConcentrations.has(`${row.brand}|${row.name}`)) { missing.push(row); continue; }
  const key = slug(`${row.brand}-${row.name}-${row.size}`);
  if (candidates.some((item) => item.key === key)) continue;
  const edition = concentration(row.name);
  const core = baseName(row.name, row.brand);
  const requestedSize = row.size.replace(/\s/g, "").toLowerCase();
  let matches = sources.filter((source) => {
    if (!source.images?.length || /alternativa|inspirad|tester|sample|set de regalo|estuche|refill|hand.*wash|soap/i.test(source.title)) return false;
    if (!normalize(source.vendor + " " + source.title).includes(normalize(row.brand.replace(/\s*\(LV\)/i, "")))) return false;
    const sourceEdition = concentration(source.title);
    if (edition && sourceEdition && edition !== sourceEdition) return false;
    if (baseName(source.title, row.brand) !== core) return false;
    const titleSizes = [...source.title.toLowerCase().matchAll(/\d+\s*ml\b/g)].map((value) => value[0].replace(/\s/g, ""));
    if (titleSizes.length && requestedSize !== "s/d" && !titleSizes.includes(requestedSize)) return false;
    return true;
  });
  const score = (source) => (/creedboutique.com|xerjoff.com/.test(source.source) ? 20 : 0)
    + (concentration(source.title) === edition ? 8 : 0)
    + (source.title.toLowerCase().replace(/\s/g, "").includes(requestedSize) ? 5 : 0)
    + (source.source.includes("silkperfumes.cl") ? 2 : 0);
  matches.sort((a, b) => score(b) - score(a));
  const override = sources.find((source) => source.handle === handleOverrides[`${row.brand}|${row.name}`]);
  const source = direct[`${row.brand}|${row.name}`] || override || matches[0];
  if (!source) { missing.push(row); continue; }
  const variant = source.variants?.find((variant) => String(variant.title).toLowerCase().replace(/\s/g, "") === requestedSize);
  const image = source.images.find((image) => variant?.featured_image?.id === image.id) || source.images[0];
  candidates.push({ ...row, key, source, remote: image.src });
}
await fs.mkdir("public/images/products", { recursive: true });
for (let offset = 0; offset < candidates.length; offset += 5) {
  await Promise.all(candidates.slice(offset, offset + 5).map(async (item) => {
    try {
      const response = await fetch(item.remote, { signal: AbortSignal.timeout(25000) });
      if (!response.ok || !response.headers.get("content-type")?.startsWith("image/")) throw new Error(`Image unavailable: ${response.status}`);
      const buffer = Buffer.from(await response.arrayBuffer());
      const image = `/images/products/${item.key}.webp`;
      await sharp(buffer).resize({ width: 900, height: 1080, fit: "inside", withoutEnlargement: true }).webp({ quality: 86 }).toFile(`public${image}`);
      mapping[item.key] = { image, source: item.source.source, sourceTitle: item.source.title, originalImage: item.remote };
    } catch (error) { missing.push(item); console.error("Pending photo", item.key, error.message); }
  }));
}
await fs.writeFile("src/lib/perfume-photos.json", JSON.stringify(mapping, null, 2) + "\n");
await fs.writeFile("/tmp/lpc-photos-pending.json", JSON.stringify(missing.map(({ brand, name, size }) => ({ brand, name, size })), null, 2));
console.log(`Imported ${Object.keys(mapping).length} original product photos; ${missing.length} references await an exact verified photo.`);
console.log("First collection photo status:", rows.slice(0, 42).map((row) => `${mapping[slug(`${row.brand}-${row.name}-${row.size}`)] ? "OK" : "PENDING"} ${row.brand} ${row.name}`).join("\n"));
