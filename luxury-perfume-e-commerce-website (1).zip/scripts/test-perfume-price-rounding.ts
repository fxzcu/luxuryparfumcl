import "dotenv/config";
import assert from "node:assert/strict";
import { asc } from "drizzle-orm";
import { db, pool } from "@/db";
import { orders, products, suppliers } from "@/db/schema";
import { applyPerfumePriceRounding, getPublicProducts } from "@/lib/catalog";
import { catalogSeeds } from "@/lib/catalog-data";
import { PERFUME_PRICE_STEP, roundPerfumePrice } from "@/lib/perfume-pricing";

async function verifyRounding() {
  for (const [input, expected] of [[0, 0], [46794, 47000], [34041, 34000], [97494, 97000], [122265, 122000], [214500, 215000], [128000, 128000]]) {
    assert.equal(roundPerfumePrice(input), expected);
    assert.equal(roundPerfumePrice(expected), expected);
  }
  assert.throws(() => roundPerfumePrice(-1));
  assert.throws(() => roundPerfumePrice(Number.NaN));
  assert.throws(() => roundPerfumePrice(12000.5));
  assert(catalogSeeds.every((product) => product.price % PERFUME_PRICE_STEP === 0));
  assert.equal(catalogSeeds.find((product) => product.name === "Brit Sheer EDT")?.price, 47000);
  assert.equal(catalogSeeds.find((product) => product.name === "Brit Sheer EDT")?.retailPrice, 71990);
  console.log("PASS: rounding is to the nearest CLP 1,000; halfway values round up; imported reference prices are preserved.");

  const before = await db.select().from(products).orderBy(asc(products.id));
  const supplierSnapshot = await db.select().from(suppliers).orderBy(asc(suppliers.id));
  const orderSnapshot = await db.select().from(orders).orderBy(asc(orders.id));
  assert(before.length > 0, "The existing catalog must be initialized before this verification.");
  const result = await applyPerfumePriceRounding();
  const after = await db.select().from(products).orderBy(asc(products.id));
  assert.equal(before.length, after.length);
  let changed = 0;
  const examples: { name: string; before: number; after: number }[] = [];
  for (let index = 0; index < before.length; index++) {
    const previous = before[index];
    const current = after[index];
    assert.equal(current.id, previous.id);
    assert.equal(current.price, roundPerfumePrice(previous.price));
    assert.equal(current.price % PERFUME_PRICE_STEP, 0);
    assert(Math.abs(current.price - previous.price) <= PERFUME_PRICE_STEP / 2);
    const { price: previousPrice, updatedAt: previousUpdatedAt, ...previousDetails } = previous;
    const { price: currentPrice, updatedAt: currentUpdatedAt, ...currentDetails } = current;
    assert.deepEqual(currentDetails, previousDetails, "Reference prices, stock and product details must not change.");
    if (currentPrice !== previousPrice) {
      changed++;
      if (examples.length < 5) examples.push({ name: `${current.brand} ${current.name}`, before: previousPrice, after: currentPrice });
    } else assert.equal(currentUpdatedAt.getTime(), previousUpdatedAt.getTime());
  }
  assert.equal(changed, result.updatedCount);
  assert.deepEqual(await db.select().from(suppliers).orderBy(asc(suppliers.id)), supplierSnapshot);
  assert.deepEqual(await db.select().from(orders).orderBy(asc(orders.id)), orderSnapshot);
  console.log(`PASS: ${after.length} catalog prices checked; ${changed} rounded. Suppliers, pack, stock, reference prices and existing orders are unchanged.`);
  if (examples.length) console.table(examples);

  assert.deepEqual(await applyPerfumePriceRounding(), { applied: false, updatedCount: 0 });
  assert.deepEqual(await db.select().from(products).orderBy(asc(products.id)), after);
  const publicCatalog = await getPublicProducts();
  const stored = new Map(after.map((product) => [product.id, product.price]));
  assert(publicCatalog.every((product) => product.price === stored.get(product.id)));
  console.log("PASS: the update is idempotent and public catalog prices match PostgreSQL.");
}

verifyRounding().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => pool.end());
