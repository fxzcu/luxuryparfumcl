import "dotenv/config";
import { count, eq, ne } from "drizzle-orm";
import { db, pool } from "@/db";
import { products, suppliers } from "@/db/schema";
import { ensureCatalogSeed } from "@/lib/catalog";
import { ensureSupplierOffers } from "@/lib/suppliers";

async function syncStore() {
  await ensureCatalogSeed();
  await ensureSupplierOffers();
  const [catalog] = await db.select({ count: count() }).from(products);
  const [withPhotos] = await db.select({ count: count() }).from(products).where(ne(products.image, ""));
  const offers = await db.select({ name: suppliers.name, price: suppliers.price }).from(suppliers).where(eq(suppliers.active, true));
  console.log({ products: catalog.count, originalPhotos: withPhotos.count, supplierOffers: offers });
}

syncStore().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => pool.end());
