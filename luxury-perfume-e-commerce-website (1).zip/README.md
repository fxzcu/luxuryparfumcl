# Luxury Parfum CL

Tienda de perfumería selecta construida con Next.js App Router, TypeScript, PostgreSQL y Drizzle ORM. Incluye catálogo con fichas SEO, búsqueda y filtros, carrito local, checkout seguro, panel de administración, inventario, proveedores y seguimiento de pedidos.

## Puesta en marcha

1. Instala dependencias con `npm install`.
2. Copia `.env.example` a `.env` y configura `DATABASE_URL`.
3. Aplica las tablas: `npx drizzle-kit push`.
4. Inicia el entorno local: `npm run dev`.
5. Abre `/admin`, inicia sesión con `ADMIN_PASSWORD` y revisa precios e inventario antes de aceptar ventas.

El catálogo de inicio se inserta de forma idempotente en la primera visita cuando la tabla de productos está vacía. Las filas duplicadas exactas se consolidan. El precio de venta toma el segundo valor proporcionado para cada perfume, redondeado al millar de CLP más cercano (por ejemplo, $46.794 → $47.000; $122.265 → $122.000). Los valores a mitad de millar se redondean hacia arriba. El primer valor se conserva sin modificar como precio de referencia. La revisión `perfume-sale-prices-nearest-1000-v1` aplica este redondeo una sola vez a los precios de venta existentes, sin cambiar proveedores, pack, existencias ni pedidos anteriores y sin sobrescribir futuras ediciones manuales. Se puede aplicar y verificar con `npx tsx scripts/test-perfume-price-rounding.ts`. Las existencias de inicio son valores operativos provisionales (8 unidades; 2 en las filas marcadas `V`); confirma el inventario real en el panel antes de publicar. La carga conserva las marcas de disponibilidad proporcionadas (`E`/`V`) y no mantiene una columna de costo de compra.

## Webpay Plus: único medio de pago — sin simulaciones

No se declara aprobado ningún pago localmente. El checkout devuelve una respuesta de configuración y no crea un pedido si no hay credenciales del proveedor. Una vez configuradas, la compra se inicia en la pasarela oficial. La aplicación nunca recibe ni guarda números de tarjetas.

### Webpay Plus / Transbank

Configura estas variables de servidor:

- `TRANSBANK_ENV=test` para integración (es el valor predeterminado si no es `production`).
- `TRANSBANK_COMMERCE_CODE` y `TRANSBANK_API_KEY` con credenciales entregadas desde el portal oficial de Transbank Developers.
- Al habilitar producción, usa `TRANSBANK_ENV=production` y las credenciales productivas aprobadas por Transbank.

La aplicación crea la transacción en Webpay Plus v1.2, envía al cliente a su URL oficial y confirma en el servidor mediante el endpoint de commit antes de marcar el pedido como pagado o descontar stock. Usa primero el ambiente de integración y las tarjetas/instrucciones de prueba vigentes en la documentación oficial de Transbank; nunca copies secretos de prueba al navegador.

### Un solo medio de pago

Las compras nuevas de perfumes, contactos de proveedores y packs se procesan exclusivamente mediante **Webpay Plus de Transbank**. Los formularios muestran Webpay sin selector y las API rechazan cualquier otro proveedor con estado 400, sin crear un pedido de pago. Los precios, canales de entrega e inventario se mantienen sin cambios.

Para no perder confirmaciones de compras antiguas, las rutas de verificación y webhook de Mercado Pago se conservan **solo para conciliación de pedidos históricos**. No permiten crear nuevos pagos. Si existen pagos antiguos pendientes, conserva `MERCADOPAGO_ACCESS_TOKEN` en el servidor hasta finalizar su conciliación; una instalación nueva no necesita esta variable. El panel identifica esos pedidos como históricos.

### Requisitos de retorno y publicación

- Configura `NEXT_PUBLIC_SITE_URL` con el dominio público definitivo, por ejemplo `https://tu-dominio.cl`. Es la base para los retornos oficiales de Webpay.
- Usa HTTPS en producción y mantén dominio, URLs permitidas y notificaciones configuradas también en los paneles oficiales.
- Nunca guardes tokens, claves de Transbank, contraseña de administración ni `DATABASE_URL` en Git o variables `NEXT_PUBLIC_*`.
- En local, el retorno de pago necesita una URL pública accesible por el proveedor; usa un túnel HTTPS temporal solo en pruebas.

## Panel de administración

- Dirección: `/admin`.
- Define `ADMIN_PASSWORD` y `ADMIN_SESSION_SECRET` en el entorno privado del servidor. Usa contraseñas largas y un secreto aleatorio de al menos 32 bytes. No hay una contraseña predeterminada.
- La sesión usa cookie `httpOnly`, `sameSite=strict`, firma HMAC y expiración de siete días. Cambiar el secreto invalida sesiones previas.
- Permite altas, ediciones y bajas de perfumes y proveedores, control de visibilidad y stock, precio de venta y referencia, fotografías, pedidos, ingresos pagados y estado de despacho.
- El stock se descuenta dentro de una transacción de base de datos solo después de confirmación server-to-server. Los precios y totales de checkout se recalculan desde PostgreSQL, nunca desde el navegador.

## Fotografías y correo

- El panel admite JPG, PNG y WEBP hasta 5 MB. En desarrollo, los archivos se guardan bajo `public/uploads/` y se referencian con una ruta local.
- El disco local de muchos servicios serverless es efímero y el directorio estático `public` se copia durante el build. Antes de uso comercial en una plataforma serverless, conecta la carga a un bucket/CDN persistente (por ejemplo, almacenamiento compatible con S3) y actualiza `/api/admin/upload` para devolver URLs HTTPS permanentes.
- Para correos de confirmación, configura `RESEND_API_KEY` y un `RESEND_FROM_EMAIL` autorizado en Resend. El correo se envía después de la confirmación oficial. Sin estas variables, el pago y el pedido funcionan, pero el envío de correo debe activarse.

## Decisiones de la tienda

- El envío de perfumes demora **entre 14 y 18 días desde la confirmación del pago**. El despacho cuesta $3.990 y es gratis desde $120.000; actualiza `SHIPPING_FEE` y `SHIPPING_THRESHOLD` en `src/lib/catalog.ts` si cambian tus tarifas.
- Retiro se ofrece previa coordinación, sin publicar una dirección hasta que la tienda la configure.
- Los proveedores se ofrecen como contactos digitales. Su precio de venta es público; el contacto es privado y solo se entrega tras confirmar el pago. No se cobran gastos de despacho por contactos.
- La familia olfativa inicial se utiliza para ayudar a filtrar; confirma notas y duración de cada edición con el proveedor antes de publicar información olfativa más específica.

## Verificaciones

```bash
npx drizzle-kit push
npx next typegen
npm exec tsc -- --noEmit
npm run build
```

La ruta `/api/health` valida la conexión PostgreSQL mediante Drizzle.

## Actualización: fotografías reales y contactos de proveedores

- Se incorporan 68 fotografías de producto verificadas, incluidos los 42 perfumes de la primera lista. Las imágenes se sirven localmente y optimizadas en `public/images/products/`.
- `src/lib/perfume-photos.json` registra para cada referencia la página fuente, su título y la imagen original. Las fuentes incluyen Creed y Xerjoff oficiales, Silk Perfumes, Disfragancias y Lookfantastic. Confirma las autorizaciones de uso comercial con las marcas o tus distribuidores antes de publicar el negocio real.
- Las ediciones cuya denominación o concentración no pudo verificarse muestran “Fotografía de esta edición en actualización”; no se utiliza un frasco genérico ni una foto de otra versión. Puedes cargar la foto correcta desde el panel.
- La actualización conserva precios, existencias y fotos personalizadas. Los cambios se aplican una sola vez mediante `store_revisions`. Puedes ejecutarlos con `npx tsx scripts/sync-store.ts` después de `npx drizzle-kit push`.

### Tres ofertas digitales

La lista anterior se reemplaza una sola vez por:
1. Proveedor de tecnología.
2. Proveedor de perfumes.
3. Proveedor de perfumes al por mayor.

En **Administración → Proveedores → Editar**, define un precio entero en CLP y completa **Contacto privado** con los datos reales que recibirá el comprador. No se han inventado precios ni contactos.

Mientras falte precio o contacto, “Comprar contacto” abre un formulario de solicitud sin cobro. Se guarda como **Solicitud · sin cobro / Por cotizar** en Pedidos, con el canal elegido. No cuenta como ingreso, no aprueba ningún pago y no se presenta al cliente como una compra completada. Una vez configurados precio y contacto, el mismo botón permite iniciar un pago exclusivamente en Webpay Plus usando las credenciales oficiales de Transbank.

### Entrega por correo o TikTok

- **Correo:** se envía el contenido privado del contacto solo después de la confirmación server-to-server del pago. Requiere `RESEND_API_KEY` y `RESEND_FROM_EMAIL`. Si falta configuración o el proveedor falla, el pedido queda pendiente de entrega; el administrador puede usar “Enviar contacto por correo” para reintentar. Se registra el envío aceptado y se utiliza una clave de idempotencia.
- **TikTok:** el comprador escribe su usuario y debe habilitar sus mensajes directos. La entrega es **manual**, desde la cuenta comercial de TikTok. El panel muestra el usuario y permite marcar el contacto como entregado. No se simula una API de mensajería de TikTok ni un envío automático.
- Los contactos privados no forman parte del HTML público, de `/api/suppliers` ni de la respuesta de compra. El correo continúa siendo obligatorio para guardar la confirmación y resolver incidencias, incluso si la entrega es por TikTok.
- Archivar un proveedor retira su oferta del público pero conserva el contenido de entrega para compras anteriores.

## Precios de proveedores y pack de los tres

Precios de venta en CLP, configurados según la actualización solicitada:

| Oferta | Precio |
| --- | ---: |
| Proveedor de tecnología | $11.990 |
| Proveedor de perfumes | $10.990 |
| Proveedor de perfumes al por mayor | $12.990 |
| Pack de los 3 proveedores | $19.990 |

El pack equivale a los tres contactos individuales ($35.970 en total), con un ahorro de $15.980. El precio y el ahorro se leen de PostgreSQL, no del navegador. No hay costo de despacho ni productos físicos incluidos.

La revisión `supplier-prices-and-three-contact-pack-v2` aplica estos precios una sola vez y conserva contactos privados, pedidos y futuras ediciones del administrador. El campo `bundle_supplier_ids` vincula el pack con exactamente un proveedor de cada categoría. Desde **Administración → Proveedores → Pack de los 3 proveedores** puedes editar su precio y sus integrantes.

Cada pedido del pack guarda la lista de los tres contactos adquiridos. Se cobra una sola línea por $19.990; el correo de entrega recupera los tres contactos después del pago confirmado. Los cambios posteriores de composición del pack no cambian los contactos de una compra ya registrada. Para TikTok, el panel muestra los tres contactos que debe enviar el equipo manualmente.

Si falta un contacto privado o las credenciales oficiales de pago, no se simula ninguna compra: se mantiene el precio publicado y se permite solicitar disponibilidad sin cobro. El pack solo habilita pagos cuando los tres proveedores están activos y sus contactos están completos.

Pruebas adicionales: `npx tsx scripts/test-supplier-bundle.ts`. Usan datos temporales y respuestas de red aisladas; no realizan cobros ni envíos reales, y eliminan sus registros al terminar.
